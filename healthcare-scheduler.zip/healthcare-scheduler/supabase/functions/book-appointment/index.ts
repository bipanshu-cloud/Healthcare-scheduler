import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

async function getGoogleAccessToken(refreshToken: string): Promise<string> {
  const clientId = Deno.env.get('GOOGLE_CLIENT_ID')!;
  const clientSecret = Deno.env.get('GOOGLE_CLIENT_SECRET')!;

  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });

  const data = await response.json();
  if (!data.access_token) throw new Error('Failed to get Google access token');
  return data.access_token;
}

async function createCalendarEvent(
  accessToken: string,
  calendarId: string,
  patientIdentifier: string,
  startTime: string,
  endTime: string,
): Promise<string> {
  const response = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        summary: `Therapy Session - ${patientIdentifier}`,
        description: 'Scheduled via MindBridge Health',
        start: { dateTime: startTime, timeZone: 'America/New_York' },
        end: { dateTime: endTime, timeZone: 'America/New_York' },
        reminders: {
          useDefault: false,
          overrides: [
            { method: 'email', minutes: 60 * 24 },
            { method: 'popup', minutes: 30 },
          ],
        },
      }),
    }
  );

  const event = await response.json();
  if (!event.id) throw new Error('Failed to create calendar event');
  return event.id;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { inquiryId, therapistId, patientIdentifier, startTime, endTime } = await req.json();

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch therapist details
    const { data: therapist, error: therapistError } = await supabase
      .from('therapists')
      .select('*')
      .eq('id', therapistId)
      .single();

    if (therapistError || !therapist) {
      throw new Error('Therapist not found');
    }

    let googleCalendarEventId: string | null = null;

    // Attempt Google Calendar integration if refresh token is available
    if (therapist.google_refresh_token && therapist.google_calendar_id) {
      try {
        const accessToken = await getGoogleAccessToken(therapist.google_refresh_token);
        googleCalendarEventId = await createCalendarEvent(
          accessToken,
          therapist.google_calendar_id,
          patientIdentifier,
          startTime,
          endTime
        );
      } catch (calError) {
        console.error('Google Calendar error (non-fatal):', calError);
        // Non-fatal: continue without calendar integration
      }
    }

    // Create appointment record
    const { data: appointment, error: aptError } = await supabase
      .from('appointments')
      .insert({
        inquiry_id: inquiryId,
        therapist_id: therapistId,
        patient_identifier: patientIdentifier,
        start_time: startTime,
        end_time: endTime,
        google_calendar_event_id: googleCalendarEventId,
        status: 'confirmed',
      })
      .select()
      .single();

    if (aptError) throw aptError;

    // Update inquiry status
    await supabase
      .from('inquiries')
      .update({ status: 'scheduled' })
      .eq('id', inquiryId);

    return new Response(
      JSON.stringify({
        success: true,
        appointment,
        calendarSynced: !!googleCalendarEventId,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('book-appointment error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
