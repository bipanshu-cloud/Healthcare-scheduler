import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify admin JWT
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Invalid token' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fetch inquiries with therapist join
    const { data: inquiries, error: inqError } = await supabase
      .from('inquiries')
      .select(`
        *,
        therapist:therapists(id, name, title, specialties)
      `)
      .order('created_at', { ascending: false });

    if (inqError) throw inqError;

    // Fetch appointments with joins
    const { data: appointments, error: aptError } = await supabase
      .from('appointments')
      .select(`
        *,
        therapist:therapists(id, name, title),
        inquiry:inquiries(id, problem_description, insurance_info)
      `)
      .order('start_time', { ascending: true });

    if (aptError) throw aptError;

    // Stats
    const stats = {
      totalInquiries: inquiries?.length || 0,
      pending: inquiries?.filter((i: any) => i.status === 'pending').length || 0,
      matched: inquiries?.filter((i: any) => i.status === 'matched').length || 0,
      scheduled: inquiries?.filter((i: any) => i.status === 'scheduled').length || 0,
      totalAppointments: appointments?.length || 0,
      upcomingAppointments: appointments?.filter((a: any) =>
        new Date(a.start_time) > new Date()
      ).length || 0,
    };

    return new Response(
      JSON.stringify({ inquiries, appointments, stats }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('get-admin-data error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
