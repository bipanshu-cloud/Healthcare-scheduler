import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { inquiryId, problem, insurance } = await req.json();

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const openaiApiKey = Deno.env.get('OPENAI_API_KEY');

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch all therapists
    const { data: therapists, error: fetchError } = await supabase
      .from('therapists')
      .select('*');

    if (fetchError) throw fetchError;

    // Use AI to determine the best specialty match
    let extractedSpecialty = '';
    if (openaiApiKey && problem) {
      const aiResp = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openaiApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [{
            role: 'user',
            content: `Given this patient problem: "${problem}"
            
Available specialties: anxiety, depression, trauma, PTSD, relationships, family therapy, couples counseling, grief, bipolar disorder, OCD, eating disorders, ADHD, autism, childhood trauma, substance abuse, addiction, life transitions, stress management

Return only the single most relevant specialty (lowercase), nothing else.`,
          }],
          temperature: 0,
        }),
      });
      const aiData = await aiResp.json();
      extractedSpecialty = aiData.choices[0].message.content.trim().toLowerCase();
    }

    // Score therapists
    const insuranceLower = (insurance || '').toLowerCase();
    const scored = (therapists || []).map((t: any) => {
      let score = 0;
      // Specialty match
      if (extractedSpecialty && t.specialties.some((s: string) => s.toLowerCase() === extractedSpecialty)) {
        score += 10;
      }
      // Partial specialty match
      if (t.specialties.some((s: string) =>
        problem?.toLowerCase().includes(s.toLowerCase()))) score += 5;
      // Insurance match
      if (t.accepted_insurance.some((ins: string) =>
        insuranceLower.includes(ins.toLowerCase()))) score += 3;
      return { ...t, score };
    });

    const matches = scored
      .filter((t: any) => t.score > 0)
      .sort((a: any, b: any) => b.score - a.score)
      .slice(0, 3);

    const finalMatches = matches.length > 0 ? matches : (therapists || []).slice(0, 3);
    const matchedId = finalMatches[0]?.id;

    // Update inquiry
    if (inquiryId) {
      await supabase
        .from('inquiries')
        .update({
          extracted_specialty: extractedSpecialty || null,
          matched_therapist_id: matchedId || null,
          status: 'matched',
        })
        .eq('id', inquiryId);
    }

    return new Response(
      JSON.stringify({ therapists: finalMatches, extractedSpecialty }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('find-therapist error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
