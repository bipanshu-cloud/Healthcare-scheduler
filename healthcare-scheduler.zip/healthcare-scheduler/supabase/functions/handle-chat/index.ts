import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { messageText, conversationHistory = [], patientIdentifier } = await req.json();

    const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Build the prompt for AI extraction
    const systemPrompt = `You are a compassionate healthcare scheduling assistant for MindBridge, a mental health platform.
Your job is to:
1. Respond empathetically to the patient's concern
2. Extract key information: the main problem/symptoms, preferred schedule, and insurance provider
3. Guide the conversation to collect missing information naturally

Respond with a JSON object:
{
  "reply": "Your empathetic response here",
  "extracted": {
    "problem": "extracted problem or null",
    "schedule": "preferred schedule or null", 
    "insurance": "insurance provider or null"
  },
  "isComplete": boolean (true when you have problem, schedule, and insurance)
}

Be warm, professional, and never clinical or cold.`;

    // Call OpenAI
    const aiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          ...conversationHistory,
          { role: 'user', content: messageText },
        ],
        response_format: { type: 'json_object' },
        temperature: 0.7,
      }),
    });

    const aiData = await aiResponse.json();
    const parsed = JSON.parse(aiData.choices[0].message.content);

    // If we have enough info, save the inquiry
    if (parsed.isComplete && parsed.extracted.problem) {
      const { data: inquiry, error } = await supabase
        .from('inquiries')
        .insert({
          patient_identifier: patientIdentifier || `anon-${Date.now()}`,
          problem_description: parsed.extracted.problem,
          requested_schedule: parsed.extracted.schedule || 'Flexible',
          insurance_info: parsed.extracted.insurance || 'Unknown',
          status: 'pending',
        })
        .select()
        .single();

      if (!error && inquiry) {
        return new Response(
          JSON.stringify({
            reply: parsed.reply,
            inquiryId: inquiry.id,
            readyToMatch: true,
            extracted: parsed.extracted,
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    return new Response(
      JSON.stringify({
        reply: parsed.reply,
        extracted: parsed.extracted,
        readyToMatch: false,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('handle-chat error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
