-- =============================================
-- MindBridge Healthcare Scheduler DB Schema
-- =============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================
-- THERAPISTS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS therapists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT 'Licensed Therapist',
  bio TEXT,
  specialties TEXT[] NOT NULL DEFAULT '{}',
  accepted_insurance TEXT[] NOT NULL DEFAULT '{}',
  avatar_url TEXT,
  google_calendar_id TEXT,
  google_refresh_token TEXT, -- Store encrypted
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- INQUIRIES TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS inquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_identifier TEXT,
  problem_description TEXT NOT NULL,
  requested_schedule TEXT,
  insurance_info TEXT,
  extracted_specialty TEXT,
  matched_therapist_id UUID REFERENCES therapists(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'matched', 'scheduled', 'failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- APPOINTMENTS TABLE
-- =============================================
CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inquiry_id UUID REFERENCES inquiries(id) ON DELETE CASCADE,
  therapist_id UUID NOT NULL REFERENCES therapists(id) ON DELETE RESTRICT,
  patient_identifier TEXT,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  google_calendar_event_id TEXT,
  status TEXT NOT NULL DEFAULT 'confirmed'
    CHECK (status IN ('confirmed', 'cancelled', 'pending')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- INDEXES
-- =============================================
CREATE INDEX IF NOT EXISTS idx_inquiries_status ON inquiries(status);
CREATE INDEX IF NOT EXISTS idx_inquiries_therapist ON inquiries(matched_therapist_id);
CREATE INDEX IF NOT EXISTS idx_appointments_therapist ON appointments(therapist_id);
CREATE INDEX IF NOT EXISTS idx_appointments_start ON appointments(start_time);

-- =============================================
-- ROW LEVEL SECURITY
-- =============================================

ALTER TABLE therapists ENABLE ROW LEVEL SECURITY;
ALTER TABLE inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

-- Therapists: public read, authenticated write
CREATE POLICY "therapists_public_read" ON therapists FOR SELECT USING (true);
CREATE POLICY "therapists_auth_write" ON therapists FOR ALL
  USING (auth.role() = 'authenticated');

-- Inquiries & Appointments: only via service role (Edge Functions) or authenticated
-- This blocks direct anon access; Edge Functions use service role key
CREATE POLICY "inquiries_service_only" ON inquiries FOR ALL
  USING (auth.role() = 'service_role' OR auth.role() = 'authenticated');

CREATE POLICY "appointments_service_only" ON appointments FOR ALL
  USING (auth.role() = 'service_role' OR auth.role() = 'authenticated');

-- =============================================
-- SEED: THERAPIST DATA
-- (Based on Chicago Counseling & Therapy team bios)
-- =============================================

INSERT INTO therapists (name, title, bio, specialties, accepted_insurance) VALUES
(
  'Dr. Sarah Mitchell',
  'Licensed Clinical Psychologist',
  'Dr. Mitchell specializes in cognitive-behavioral therapy with over 12 years helping patients overcome anxiety and trauma. She creates a warm, non-judgmental space for healing and uses evidence-based approaches to address anxiety, depression, and PTSD.',
  ARRAY['anxiety', 'depression', 'trauma', 'PTSD'],
  ARRAY['aetna', 'bluecross', 'cigna', 'united']
),
(
  'Dr. James Okonkwo',
  'Marriage & Family Therapist',
  'With a focus on systemic therapy, Dr. Okonkwo helps families and couples navigate conflict, improve communication, and build stronger bonds. He uses narrative and solution-focused approaches to resolve relationship challenges.',
  ARRAY['relationships', 'family therapy', 'couples counseling', 'grief'],
  ARRAY['bluecross', 'humana', 'medicaid', 'aetna']
),
(
  'Dr. Elena Vasquez',
  'Psychiatrist & Therapist',
  'Board-certified psychiatrist combining medication management with psychotherapy. Dr. Vasquez takes a holistic approach to mental wellness, specializing in complex psychiatric conditions and medication optimization.',
  ARRAY['bipolar disorder', 'schizophrenia', 'OCD', 'eating disorders'],
  ARRAY['united', 'cigna', 'medicare', 'aetna']
),
(
  'Dr. Marcus Chen',
  'Adolescent & Child Psychologist',
  'Dedicated to helping children and adolescents thrive, Dr. Chen uses play therapy and family-centered approaches to address developmental challenges. He specializes in ADHD, autism spectrum disorder, and childhood behavioral issues.',
  ARRAY['ADHD', 'autism', 'childhood trauma', 'learning disabilities'],
  ARRAY['bluecross', 'aetna', 'humana', 'tricare']
),
(
  'Dr. Priya Sharma',
  'Licensed Clinical Social Worker',
  'Dr. Sharma brings compassion and evidence-based practice to addiction and recovery. She specializes in motivational interviewing, harm reduction strategies, and helping clients navigate major life transitions.',
  ARRAY['substance abuse', 'addiction', 'life transitions', 'stress management'],
  ARRAY['medicaid', 'medicare', 'cigna', 'humana']
);
