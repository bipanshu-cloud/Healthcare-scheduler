import { Star, Shield, Clock } from 'lucide-react';
import { Therapist } from '../types';
import styles from './TherapistCard.module.css';

interface Props {
  therapist: Therapist;
  onSelect: (therapist: Therapist) => void;
  compact?: boolean;
}

const AVATAR_COLORS = [
  { bg: '#E8F0E8', color: '#2E5C31' },
  { bg: '#E8EAF6', color: '#3949AB' },
  { bg: '#FFF3E0', color: '#E65100' },
  { bg: '#F3E5F5', color: '#7B1FA2' },
  { bg: '#E3F2FD', color: '#1565C0' },
];

export default function TherapistCard({ therapist, onSelect }: Props) {
  const colorIndex = therapist.id.charCodeAt(0) % AVATAR_COLORS.length;
  const colors = AVATAR_COLORS[colorIndex];

  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div className={styles.avatar} style={{ background: colors.bg, color: colors.color }}>
          {therapist.avatar_url || therapist.name.split(' ').map(n => n[0]).join('').slice(0,2)}
        </div>
        <div className={styles.info}>
          <div className={styles.name}>{therapist.name}</div>
          <div className={styles.title}>{therapist.title}</div>
          <div className={styles.rating}>
            <Star size={11} fill="#C9A84C" color="#C9A84C" />
            <span>4.9</span>
            <span className={styles.ratingCount}>(48 reviews)</span>
          </div>
        </div>
      </div>

      <p className={styles.bio}>{therapist.bio}</p>

      <div className={styles.tags}>
        {therapist.specialties.slice(0, 3).map(s => (
          <span key={s} className={styles.tag}>{s}</span>
        ))}
      </div>

      <div className={styles.meta}>
        <div className={styles.metaItem}>
          <Shield size={13} />
          <span>{therapist.accepted_insurance.slice(0, 2).join(', ')}{therapist.accepted_insurance.length > 2 ? ` +${therapist.accepted_insurance.length - 2}` : ''}</span>
        </div>
        <div className={styles.metaItem}>
          <Clock size={13} />
          <span>Next available: Tomorrow</span>
        </div>
      </div>

      <button className={styles.selectBtn} onClick={() => onSelect(therapist)}>
        Book with {therapist.name.split(' ')[1]}
      </button>
    </div>
  );
}
