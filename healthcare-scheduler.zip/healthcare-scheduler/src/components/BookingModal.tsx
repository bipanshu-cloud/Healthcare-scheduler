import { useState } from 'react';
import { X, Calendar, Clock, CheckCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import { Therapist } from '../types';
import styles from './BookingModal.module.css';

interface Props {
  therapist: Therapist;
  preferredSchedule?: string;
  onConfirm: (therapist: Therapist, timeSlot: string) => void;
  onClose: () => void;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

const TIME_SLOTS = [
  '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM',
  '11:00 AM', '11:30 AM', '2:00 PM', '2:30 PM',
  '3:00 PM', '3:30 PM', '4:00 PM', '5:00 PM',
  '5:30 PM', '6:00 PM', '6:30 PM', '7:00 PM',
];

// Randomly mark some slots as unavailable
const UNAVAILABLE = [1, 4, 7, 11, 14];

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfMonth(year: number, month: number) {
  return new Date(year, month, 1).getDay();
}

export default function BookingModal({ therapist, onConfirm, onClose }: Props) {
  const today = new Date();
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selectedDate, setSelectedDate] = useState<number | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [step, setStep] = useState<'pick' | 'confirm'>('pick');
  const [patientName, setPatientName] = useState('');
  const [patientEmail, setPatientEmail] = useState('');

  const daysInMonth = getDaysInMonth(viewYear, viewMonth);
  const firstDay = getFirstDayOfMonth(viewYear, viewMonth);
  const totalCells = Math.ceil((firstDay + daysInMonth) / 7) * 7;

  const prevMonth = () => {
    if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1); }
    else setViewMonth(m => m - 1);
    setSelectedDate(null);
  };

  const nextMonth = () => {
    if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1); }
    else setViewMonth(m => m + 1);
    setSelectedDate(null);
  };

  const isPast = (day: number) => {
    const d = new Date(viewYear, viewMonth, day);
    return d < new Date(today.getFullYear(), today.getMonth(), today.getDate());
  };

  const isToday = (day: number) => {
    return viewYear === today.getFullYear() && viewMonth === today.getMonth() && day === today.getDate();
  };

  const handleConfirm = () => {
    if (!selectedDate || !selectedTime || !patientName || !patientEmail) return;
    const dateStr = `${MONTHS[viewMonth]} ${selectedDate}, ${viewYear}`;
    const slot = `${dateStr} at ${selectedTime}`;
    onConfirm(therapist, slot);
  };

  const canProceed = selectedDate && selectedTime;

  const AVATAR_COLORS = [
    { bg: '#E8F0E8', color: '#2E5C31' },
    { bg: '#E8EAF6', color: '#3949AB' },
    { bg: '#FFF3E0', color: '#E65100' },
    { bg: '#F3E5F5', color: '#7B1FA2' },
    { bg: '#E3F2FD', color: '#1565C0' },
  ];
  const colorIndex = therapist.id.charCodeAt(0) % AVATAR_COLORS.length;
  const colors = AVATAR_COLORS[colorIndex];

  return (
    <div className={styles.overlay} onClick={e => e.target === e.currentTarget && onClose()}>
      <div className={styles.modal}>
        {/* Modal Header */}
        <div className={styles.modalHeader}>
          <div className={styles.therapistInfo}>
            <div className={styles.therapistAvatar} style={{ background: colors.bg, color: colors.color }}>
              {therapist.avatar_url || therapist.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </div>
            <div>
              <div className={styles.therapistName}>{therapist.name}</div>
              <div className={styles.therapistTitle}>{therapist.title}</div>
            </div>
          </div>
          <button className={styles.closeBtn} onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        {step === 'pick' ? (
          <>
            <div className={styles.stepLabel}>
              <Calendar size={15} />
              <span>Select a date & time</span>
            </div>

            {/* Calendar */}
            <div className={styles.calendar}>
              <div className={styles.calNav}>
                <button className={styles.calNavBtn} onClick={prevMonth}><ChevronLeft size={16} /></button>
                <span className={styles.calMonth}>{MONTHS[viewMonth]} {viewYear}</span>
                <button className={styles.calNavBtn} onClick={nextMonth}><ChevronRight size={16} /></button>
              </div>
              <div className={styles.calGrid}>
                {DAYS.map(d => (
                  <div key={d} className={styles.calDayLabel}>{d}</div>
                ))}
                {Array.from({ length: totalCells }).map((_, i) => {
                  const day = i - firstDay + 1;
                  if (day < 1 || day > daysInMonth) return <div key={i} />;
                  const past = isPast(day);
                  const today_ = isToday(day);
                  const selected = selectedDate === day;
                  return (
                    <button
                      key={i}
                      className={`${styles.calDay} ${past ? styles.calDayPast : ''} ${today_ ? styles.calDayToday : ''} ${selected ? styles.calDaySelected : ''}`}
                      onClick={() => !past && setSelectedDate(day)}
                      disabled={past}
                    >
                      {day}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Time Slots */}
            {selectedDate && (
              <div className={styles.timeSection}>
                <div className={styles.stepLabel}>
                  <Clock size={15} />
                  <span>Available times on {MONTHS[viewMonth]} {selectedDate}</span>
                </div>
                <div className={styles.timeGrid}>
                  {TIME_SLOTS.map((slot, i) => {
                    const unavail = UNAVAILABLE.includes(i);
                    return (
                      <button
                        key={slot}
                        className={`${styles.timeSlot} ${unavail ? styles.timeSlotUnavail : ''} ${selectedTime === slot ? styles.timeSlotSelected : ''}`}
                        onClick={() => !unavail && setSelectedTime(slot)}
                        disabled={unavail}
                      >
                        {slot}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className={styles.modalFooter}>
              <button className={styles.cancelBtn} onClick={onClose}>Cancel</button>
              <button
                className={styles.nextBtn}
                disabled={!canProceed}
                onClick={() => setStep('confirm')}
              >
                Continue
              </button>
            </div>
          </>
        ) : (
          <>
            <div className={styles.stepLabel}>
              <CheckCircle size={15} />
              <span>Confirm your booking</span>
            </div>

            <div className={styles.confirmSummary}>
              <div className={styles.confirmRow}>
                <Calendar size={15} />
                <span>{MONTHS[viewMonth]} {selectedDate}, {viewYear}</span>
              </div>
              <div className={styles.confirmRow}>
                <Clock size={15} />
                <span>{selectedTime} · 50-minute session</span>
              </div>
            </div>

            <div className={styles.formFields}>
              <div className={styles.field}>
                <label className={styles.label}>Your name</label>
                <input
                  className={styles.fieldInput}
                  placeholder="Full name"
                  value={patientName}
                  onChange={e => setPatientName(e.target.value)}
                />
              </div>
              <div className={styles.field}>
                <label className={styles.label}>Email address</label>
                <input
                  className={styles.fieldInput}
                  type="email"
                  placeholder="For confirmation email"
                  value={patientEmail}
                  onChange={e => setPatientEmail(e.target.value)}
                />
              </div>
            </div>

            <p className={styles.disclaimer}>
              By booking, you agree to our cancellation policy. Appointments cancelled less than 24 hours in advance may incur a fee.
            </p>

            <div className={styles.modalFooter}>
              <button className={styles.cancelBtn} onClick={() => setStep('pick')}>Back</button>
              <button
                className={styles.confirmBtn}
                disabled={!patientName || !patientEmail}
                onClick={handleConfirm}
              >
                <CheckCircle size={16} />
                Confirm Booking
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
