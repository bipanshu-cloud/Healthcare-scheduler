import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Users, Calendar, Activity, TrendingUp,
  Search, Filter, MoreHorizontal, CheckCircle, Clock,
  AlertCircle, Heart, LogOut, Bell, ChevronDown
} from 'lucide-react';
import { MOCK_INQUIRIES, MOCK_APPOINTMENTS, MOCK_THERAPISTS } from '../lib/mockData';
import { Inquiry, Appointment } from '../types';
import styles from './AdminPage.module.css';

// Simple in-memory auth
const ADMIN_EMAIL = 'admin@mindbridge.health';
const ADMIN_PASS = 'demo1234';

type Tab = 'overview' | 'inquiries' | 'appointments' | 'therapists';

export default function AdminPage() {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [loading, setLoading] = useState(false);

  const inquiries: Inquiry[] = MOCK_INQUIRIES;
  const appointments: Appointment[] = MOCK_APPOINTMENTS;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      if (email === ADMIN_EMAIL && password === ADMIN_PASS) {
        setIsLoggedIn(true);
        setLoginError('');
      } else {
        setLoginError('Invalid credentials. Try admin@mindbridge.health / demo1234');
      }
      setLoading(false);
    }, 800);
  };

  const filteredInquiries = inquiries.filter(i => {
    const matchSearch = !searchQuery ||
      i.problem_description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      i.insurance_info.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (i.extracted_specialty || '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchStatus = statusFilter === 'all' || i.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const filteredAppointments = appointments.filter(a => {
    return !searchQuery ||
      (a.therapist?.name || '').toLowerCase().includes(searchQuery.toLowerCase());
  });

  // Stats
  const stats = {
    totalInquiries: inquiries.length,
    scheduled: inquiries.filter(i => i.status === 'scheduled').length,
    pending: inquiries.filter(i => i.status === 'pending').length,
    matched: inquiries.filter(i => i.status === 'matched').length,
    totalAppointments: appointments.length,
    upcomingAppointments: appointments.filter(a => new Date(a.start_time) > new Date()).length,
  };

  if (!isLoggedIn) {
    return (
      <div className={styles.loginPage}>
        <div className={styles.loginDecor} />
        <div className={styles.loginBox}>
          <div className={styles.loginHeader}>
            <div className={styles.loginLogo}>
              <Heart size={20} fill="currentColor" />
            </div>
            <h1 className={styles.loginTitle}>Admin Portal</h1>
            <p className={styles.loginSubtitle}>MindBridge Health Dashboard</p>
          </div>

          <form className={styles.loginForm} onSubmit={handleLogin}>
            <div className={styles.loginField}>
              <label className={styles.loginLabel}>Email</label>
              <input
                className={styles.loginInput}
                type="email"
                placeholder="admin@mindbridge.health"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
            <div className={styles.loginField}>
              <label className={styles.loginLabel}>Password</label>
              <input
                className={styles.loginInput}
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>
            {loginError && <p className={styles.loginError}>{loginError}</p>}
            <button className={styles.loginBtn} type="submit" disabled={loading}>
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <p className={styles.loginHint}>
            Demo: admin@mindbridge.health / demo1234
          </p>

          <button className={styles.loginBack} onClick={() => navigate('/')}>
            <ArrowLeft size={14} />
            Back to homepage
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.dashboard}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarBrand}>
          <div className={styles.sidebarLogo}>
            <Heart size={16} fill="currentColor" />
          </div>
          <span className={styles.sidebarName}>MindBridge</span>
        </div>

        <nav className={styles.sidebarNav}>
          {[
            { id: 'overview', label: 'Overview', icon: Activity },
            { id: 'inquiries', label: 'Inquiries', icon: Users },
            { id: 'appointments', label: 'Appointments', icon: Calendar },
            { id: 'therapists', label: 'Therapists', icon: Heart },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={`${styles.sidebarItem} ${activeTab === id ? styles.sidebarItemActive : ''}`}
              onClick={() => setActiveTab(id as Tab)}
            >
              <Icon size={18} />
              <span>{label}</span>
              {id === 'inquiries' && stats.pending > 0 && (
                <span className={styles.badge}>{stats.pending}</span>
              )}
            </button>
          ))}
        </nav>

        <div className={styles.sidebarFooter}>
          <div className={styles.sidebarUser}>
            <div className={styles.sidebarUserAvatar}>A</div>
            <div>
              <div className={styles.sidebarUserName}>Admin</div>
              <div className={styles.sidebarUserEmail}>admin@mindbridge.health</div>
            </div>
          </div>
          <button className={styles.logoutBtn} onClick={() => setIsLoggedIn(false)}>
            <LogOut size={16} />
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className={styles.main}>
        {/* Top bar */}
        <div className={styles.topBar}>
          <div>
            <h2 className={styles.pageTitle}>
              {activeTab === 'overview' && 'Overview'}
              {activeTab === 'inquiries' && 'Patient Inquiries'}
              {activeTab === 'appointments' && 'Appointments'}
              {activeTab === 'therapists' && 'Therapist Directory'}
            </h2>
            <p className={styles.pageDate}>
              {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div className={styles.topBarActions}>
            <button className={styles.topBarBtn}><Bell size={17} /></button>
            <button className={styles.newPatientBtn} onClick={() => navigate('/chat')}>
              + New Inquiry
            </button>
          </div>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className={styles.tabContent}>
            <div className={styles.statsGrid}>
              <div className={styles.statCard}>
                <div className={styles.statIcon} style={{ background: '#EEF4EE', color: 'var(--sage-dark)' }}>
                  <Users size={22} />
                </div>
                <div>
                  <div className={styles.statNum}>{stats.totalInquiries}</div>
                  <div className={styles.statLabel}>Total Inquiries</div>
                </div>
                <div className={styles.statTrend}>
                  <TrendingUp size={14} />
                  <span>+12%</span>
                </div>
              </div>
              <div className={styles.statCard}>
                <div className={styles.statIcon} style={{ background: '#E8F5E8', color: '#27AE60' }}>
                  <CheckCircle size={22} />
                </div>
                <div>
                  <div className={styles.statNum}>{stats.scheduled}</div>
                  <div className={styles.statLabel}>Scheduled</div>
                </div>
                <div className={styles.statTrend}>
                  <TrendingUp size={14} />
                  <span>+8%</span>
                </div>
              </div>
              <div className={styles.statCard}>
                <div className={styles.statIcon} style={{ background: '#FFF8E1', color: '#F9A825' }}>
                  <Clock size={22} />
                </div>
                <div>
                  <div className={styles.statNum}>{stats.pending}</div>
                  <div className={styles.statLabel}>Pending Review</div>
                </div>
                <div className={styles.statTrendWarn}>
                  <AlertCircle size={14} />
                  <span>Needs attention</span>
                </div>
              </div>
              <div className={styles.statCard}>
                <div className={styles.statIcon} style={{ background: '#EEF0FF', color: '#5C6AC4' }}>
                  <Calendar size={22} />
                </div>
                <div>
                  <div className={styles.statNum}>{stats.upcomingAppointments}</div>
                  <div className={styles.statLabel}>Upcoming Appts</div>
                </div>
                <div className={styles.statTrend}>
                  <TrendingUp size={14} />
                  <span>This week</span>
                </div>
              </div>
            </div>

            {/* Recent Inquiries */}
            <div className={styles.section}>
              <div className={styles.sectionHeader}>
                <h3 className={styles.sectionTitle}>Recent Inquiries</h3>
                <button className={styles.sectionLink} onClick={() => setActiveTab('inquiries')}>View all</button>
              </div>
              <InquiriesTable inquiries={inquiries.slice(0, 3)} />
            </div>

            {/* Upcoming Appointments */}
            <div className={styles.section}>
              <div className={styles.sectionHeader}>
                <h3 className={styles.sectionTitle}>Upcoming Appointments</h3>
                <button className={styles.sectionLink} onClick={() => setActiveTab('appointments')}>View all</button>
              </div>
              <AppointmentsTable appointments={appointments} />
            </div>
          </div>
        )}

        {/* Inquiries Tab */}
        {activeTab === 'inquiries' && (
          <div className={styles.tabContent}>
            <div className={styles.tableControls}>
              <div className={styles.searchBox}>
                <Search size={16} className={styles.searchIcon} />
                <input
                  className={styles.searchInput}
                  placeholder="Search inquiries..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
              <div className={styles.filterGroup}>
                <Filter size={15} />
                <select
                  className={styles.filterSelect}
                  value={statusFilter}
                  onChange={e => setStatusFilter(e.target.value)}
                >
                  <option value="all">All Status</option>
                  <option value="pending">Pending</option>
                  <option value="matched">Matched</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="failed">Failed</option>
                </select>
              </div>
            </div>
            <InquiriesTable inquiries={filteredInquiries} />
          </div>
        )}

        {/* Appointments Tab */}
        {activeTab === 'appointments' && (
          <div className={styles.tabContent}>
            <div className={styles.tableControls}>
              <div className={styles.searchBox}>
                <Search size={16} className={styles.searchIcon} />
                <input
                  className={styles.searchInput}
                  placeholder="Search appointments..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <AppointmentsTable appointments={filteredAppointments} />
          </div>
        )}

        {/* Therapists Tab */}
        {activeTab === 'therapists' && (
          <div className={styles.tabContent}>
            <div className={styles.therapistGrid}>
              {MOCK_THERAPISTS.map(t => {
                const COLORS = [
                  { bg: '#E8F0E8', color: '#2E5C31' },
                  { bg: '#E8EAF6', color: '#3949AB' },
                  { bg: '#FFF3E0', color: '#E65100' },
                  { bg: '#F3E5F5', color: '#7B1FA2' },
                  { bg: '#E3F2FD', color: '#1565C0' },
                ];
                const c = COLORS[parseInt(t.id) % COLORS.length];
                const apptCount = appointments.filter(a => a.therapist_id === t.id).length;
                return (
                  <div key={t.id} className={styles.therapistAdminCard}>
                    <div className={styles.tacHeader}>
                      <div className={styles.tacAvatar} style={{ background: c.bg, color: c.color }}>
                        {t.avatar_url}
                      </div>
                      <div>
                        <div className={styles.tacName}>{t.name}</div>
                        <div className={styles.tacTitle}>{t.title}</div>
                      </div>
                    </div>
                    <p className={styles.tacBio}>{t.bio}</p>
                    <div className={styles.tacTags}>
                      {t.specialties.map(s => (
                        <span key={s} className={styles.tacTag}>{s}</span>
                      ))}
                    </div>
                    <div className={styles.tacMeta}>
                      <div className={styles.tacMetaItem}>
                        <Calendar size={13} />
                        <span>{apptCount} appointments</span>
                      </div>
                      <div className={styles.tacMetaItem}>
                        <CheckCircle size={13} />
                        <span>Active</span>
                      </div>
                    </div>
                    <div className={styles.tacInsurance}>
                      {t.accepted_insurance.map(ins => (
                        <span key={ins} className={styles.tacInsTag}>{ins}</span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

// Sub-components

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    pending: { label: 'Pending', cls: 'warn' },
    matched: { label: 'Matched', cls: 'info' },
    scheduled: { label: 'Scheduled', cls: 'success' },
    failed: { label: 'Failed', cls: 'error' },
    confirmed: { label: 'Confirmed', cls: 'success' },
    cancelled: { label: 'Cancelled', cls: 'error' },
  };
  const { label, cls } = map[status] || { label: status, cls: 'info' };
  return <span className={`${styles.statusBadge} ${styles[`badge_${cls}`]}`}>{label}</span>;
}

function InquiriesTable({ inquiries }: { inquiries: Inquiry[] }) {
  return (
    <div className={styles.tableWrapper}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Patient</th>
            <th>Problem</th>
            <th>Specialty</th>
            <th>Insurance</th>
            <th>Therapist</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {inquiries.map(inq => (
            <tr key={inq.id}>
              <td>
                <div className={styles.patientCell}>
                  <div className={styles.patientAvatar}>
                    {inq.patient_identifier.slice(-2).toUpperCase()}
                  </div>
                  <span>{inq.patient_identifier.replace('patient-hash-', 'Patient #')}</span>
                </div>
              </td>
              <td>
                <div className={styles.problemCell}>
                  {inq.problem_description.slice(0, 60)}…
                </div>
              </td>
              <td>
                {inq.extracted_specialty
                  ? <span className={styles.specialtyTag}>{inq.extracted_specialty}</span>
                  : <span className={styles.emptyCell}>—</span>
                }
              </td>
              <td>{inq.insurance_info}</td>
              <td>
                {inq.therapist
                  ? <span className={styles.therapistCell}>{inq.therapist.name}</span>
                  : <span className={styles.emptyCell}>Unmatched</span>
                }
              </td>
              <td><StatusBadge status={inq.status} /></td>
              <td className={styles.dateCell}>
                {new Date(inq.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {inquiries.length === 0 && (
        <div className={styles.emptyTable}>No inquiries found.</div>
      )}
    </div>
  );
}

function AppointmentsTable({ appointments }: { appointments: Appointment[] }) {
  return (
    <div className={styles.tableWrapper}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Patient</th>
            <th>Therapist</th>
            <th>Date & Time</th>
            <th>Duration</th>
            <th>Calendar</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {appointments.map(apt => (
            <tr key={apt.id}>
              <td>
                <div className={styles.patientCell}>
                  <div className={styles.patientAvatar}>
                    {apt.patient_identifier.slice(-2).toUpperCase()}
                  </div>
                  <span>{apt.patient_identifier.replace('patient-hash-', 'Patient #')}</span>
                </div>
              </td>
              <td>
                <span className={styles.therapistCell}>{apt.therapist?.name || '—'}</span>
              </td>
              <td>
                <div className={styles.dateTimeCell}>
                  <span className={styles.dateMain}>
                    {new Date(apt.start_time).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                  <span className={styles.dateSub}>
                    {new Date(apt.start_time).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                  </span>
                </div>
              </td>
              <td>50 min</td>
              <td>
                {apt.google_calendar_event_id
                  ? <span className={styles.calLinked}><CheckCircle size={13} /> Synced</span>
                  : <span className={styles.calPending}><Clock size={13} /> Pending</span>
                }
              </td>
              <td><StatusBadge status={apt.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
      {appointments.length === 0 && (
        <div className={styles.emptyTable}>No appointments found.</div>
      )}
    </div>
  );
}
