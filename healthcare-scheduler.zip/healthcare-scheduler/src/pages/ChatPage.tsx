import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Heart, Calendar, CheckCircle, Loader2, User, Sparkles } from 'lucide-react';
import { ChatMessage, ChatState, Therapist } from '../types';
import { MOCK_THERAPISTS, matchTherapists } from '../lib/mockData';
import TherapistCard from '../components/TherapistCard';
import BookingModal from '../components/BookingModal';
import styles from './ChatPage.module.css';

const BOT_INTRO = `Hello! I'm the MindBridge scheduling assistant. 🌿

I'm here to help connect you with the right therapist for your needs. Our conversation is completely confidential.

To get started, could you tell me a bit about what brings you here today? Please share as much or as little as you're comfortable with.`;

const INSURANCE_OPTIONS = ['Aetna', 'BlueCross BlueShield', 'Cigna', 'Humana', 'United Healthcare', 'Medicaid', 'Medicare', 'Tricare', 'Self-pay / No insurance'];

function generateId() {
  return Math.random().toString(36).substr(2, 9);
}

function botMessage(text: string, extras?: Partial<ChatMessage>): ChatMessage {
  return { id: generateId(), sender: 'bot', text, timestamp: new Date(), ...extras };
}

export default function ChatPage() {
  const navigate = useNavigate();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [input, setInput] = useState('');
  const [bookingTherapist, setBookingTherapist] = useState<Therapist | null>(null);
  const [state, setState] = useState<ChatState>({
    messages: [botMessage(BOT_INTRO)],
    isLoading: false,
    stage: 'intro',
    collectedInfo: {},
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.messages, state.isLoading]);

  const addMessage = (msg: ChatMessage) => {
    setState(prev => ({ ...prev, messages: [...prev.messages, msg] }));
  };

  const addBotMessage = (text: string, extras?: Partial<ChatMessage>) => {
    addMessage(botMessage(text, extras));
  };

  const simulateTyping = (callback: () => void, delay = 1200) => {
    setState(prev => ({ ...prev, isLoading: true }));
    setTimeout(() => {
      setState(prev => ({ ...prev, isLoading: false }));
      callback();
    }, delay);
  };

  const handleSend = () => {
    const trimmed = input.trim();
    if (!trimmed || state.isLoading) return;
    setInput('');

    const userMsg: ChatMessage = { id: generateId(), sender: 'user', text: trimmed, timestamp: new Date() };
    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMsg],
    }));

    processUserInput(trimmed);
  };

  const processUserInput = (text: string) => {
    const { stage, collectedInfo } = state;

    if (stage === 'intro') {
      setState(prev => ({ ...prev, stage: 'collecting', collectedInfo: { problem: text } }));
      simulateTyping(() => {
        addBotMessage(`Thank you for sharing that. It takes courage to reach out, and I want you to know you're in the right place.\n\nTo help find the best match for you, do you have a preference for when you'd like to meet? For example: weekday evenings, weekend mornings, or are you flexible?`);
      });
    } else if (stage === 'collecting' && !collectedInfo.schedule) {
      setState(prev => ({ ...prev, collectedInfo: { ...prev.collectedInfo, schedule: text } }));
      simulateTyping(() => {
        addBotMessage(`Perfect. One more important question — what health insurance do you have? This helps me find therapists who are in-network for you.\n\nYou can type your insurance provider or choose from the options below.`, { type: 'text' });
        // Show insurance quick options
        setTimeout(() => {
          addBotMessage('', { type: 'text', text: '__INSURANCE_OPTIONS__' });
        }, 200);
      });
    } else if (stage === 'collecting' && !collectedInfo.insurance) {
      const insurance = text;
      const problem = collectedInfo.problem || '';
      setState(prev => ({ ...prev, collectedInfo: { ...prev.collectedInfo, insurance }, stage: 'matching' }));

      simulateTyping(() => {
        addBotMessage(`Great! I'm now searching our network of therapists who specialize in what you've described and accept ${insurance}...`);
      }, 800);

      setTimeout(() => {
        const matches = matchTherapists(problem, insurance);
        const therapistsToShow = matches.length > 0 ? matches : MOCK_THERAPISTS.slice(0, 3);

        simulateTyping(() => {
          addBotMessage(
            `I found ${therapistsToShow.length} therapist${therapistsToShow.length > 1 ? 's' : ''} who are an excellent match for you. Here are your options:`,
            { type: 'therapist-options', therapists: therapistsToShow }
          );
          setState(prev => ({ ...prev, matchedTherapists: therapistsToShow }));
        }, 1500);
      }, 1600);
    }
  };

  const handleSelectTherapist = (therapist: Therapist) => {
    setBookingTherapist(therapist);
  };

  const handleBookingConfirm = (therapist: Therapist, timeSlot: string) => {
    setBookingTherapist(null);
    setState(prev => ({ ...prev, stage: 'booking' }));

    addMessage({
      id: generateId(),
      sender: 'user',
      text: `I'd like to book with ${therapist.name} at ${timeSlot}`,
      timestamp: new Date(),
    });

    simulateTyping(() => {
      addBotMessage(`✅ Your appointment has been successfully booked!\n\n📅 **${therapist.name}**\n🕐 ${timeSlot}\n📧 A confirmation will be sent to your email\n📲 The appointment has been added to ${therapist.name}'s calendar\n\nIs there anything else you'd like to know before your first session?`, {
        type: 'success'
      });
      setState(prev => ({ ...prev, stage: 'confirmed' }));
    }, 2000);
  };

  const handleQuickReply = (option: string) => {
    setInput(option);
    setTimeout(() => {
      const userMsg: ChatMessage = { id: generateId(), sender: 'user', text: option, timestamp: new Date() };
      setState(prev => ({
        ...prev,
        messages: prev.messages.filter(m => m.text !== '__INSURANCE_OPTIONS__'),
      }));
      setState(prev => ({
        ...prev,
        messages: [...prev.messages, userMsg],
      }));
      setInput('');
      processUserInput(option);
    }, 50);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className={styles.page}>
      {/* Header */}
      <header className={styles.header}>
        <button className={styles.backBtn} onClick={() => navigate('/')}>
          <ArrowLeft size={18} />
        </button>
        <div className={styles.headerBrand}>
          <div className={styles.headerAvatar}>
            <Sparkles size={16} />
          </div>
          <div>
            <div className={styles.headerTitle}>MindBridge AI</div>
            <div className={styles.headerStatus}>
              <span className={styles.statusDot} />
              Available now
            </div>
          </div>
        </div>
        <button className={styles.calendarBtn} onClick={() => navigate('/admin')}>
          <Calendar size={18} />
          <span>Admin</span>
        </button>
      </header>

      {/* Messages */}
      <div className={styles.messages}>
        <div className={styles.messagesInner}>
          {state.messages.map((msg, i) => {
            if (msg.text === '__INSURANCE_OPTIONS__') {
              return (
                <div key={msg.id} className={styles.quickReplies}>
                  {INSURANCE_OPTIONS.map(opt => (
                    <button key={opt} className={styles.quickReply} onClick={() => handleQuickReply(opt)}>
                      {opt}
                    </button>
                  ))}
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                className={`${styles.msgWrapper} ${msg.sender === 'user' ? styles.userWrapper : styles.botWrapper}`}
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                {msg.sender === 'bot' && (
                  <div className={styles.botAvatar}>
                    <Heart size={12} fill="currentColor" />
                  </div>
                )}
                <div className={`${styles.bubble} ${msg.sender === 'user' ? styles.userBubble : styles.botBubble} ${msg.type === 'success' ? styles.successBubble : ''}`}>
                  {msg.type === 'success' && (
                    <div className={styles.successIcon}>
                      <CheckCircle size={20} />
                    </div>
                  )}
                  <div className={styles.msgText}>
                    {msg.text.split('\n').map((line, j) => (
                      <span key={j}>
                        {line.replace(/\*\*(.*?)\*\*/g, '$1')}
                        {j < msg.text.split('\n').length - 1 && <br />}
                      </span>
                    ))}
                  </div>
                  {msg.type === 'therapist-options' && msg.therapists && (
                    <div className={styles.therapistOptions}>
                      {msg.therapists.map(t => (
                        <TherapistCard
                          key={t.id}
                          therapist={t}
                          onSelect={handleSelectTherapist}
                        />
                      ))}
                    </div>
                  )}
                </div>
                {msg.sender === 'user' && (
                  <div className={styles.userAvatar}>
                    <User size={14} />
                  </div>
                )}
              </div>
            );
          })}

          {/* Typing indicator */}
          {state.isLoading && (
            <div className={`${styles.msgWrapper} ${styles.botWrapper}`}>
              <div className={styles.botAvatar}>
                <Heart size={12} fill="currentColor" />
              </div>
              <div className={`${styles.bubble} ${styles.botBubble}`}>
                <div className={styles.typingIndicator}>
                  <span /><span /><span />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className={styles.inputArea}>
        {state.stage === 'confirmed' ? (
          <div className={styles.confirmedState}>
            <CheckCircle size={18} className={styles.confirmedIcon} />
            <span>Appointment booked! We'll see you soon. 🌿</span>
          </div>
        ) : (
          <div className={styles.inputRow}>
            <input
              ref={inputRef}
              className={styles.input}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message..."
              disabled={state.isLoading}
            />
            <button
              className={styles.sendBtn}
              onClick={handleSend}
              disabled={!input.trim() || state.isLoading}
            >
              {state.isLoading ? <Loader2 size={18} className={styles.spinner} /> : <Send size={18} />}
            </button>
          </div>
        )}
        <div className={styles.inputFooter}>
          <span>🔒 Confidential & secure</span>
          <span>·</span>
          <span>Not a crisis service — if in immediate danger, call 911</span>
        </div>
      </div>

      {/* Booking Modal */}
      {bookingTherapist && (
        <BookingModal
          therapist={bookingTherapist}
          preferredSchedule={state.collectedInfo.schedule}
          onConfirm={handleBookingConfirm}
          onClose={() => setBookingTherapist(null)}
        />
      )}
    </div>
  );
}
