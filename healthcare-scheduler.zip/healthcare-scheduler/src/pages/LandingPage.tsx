import { useNavigate } from 'react-router-dom';
import { ArrowRight, Shield, Clock, Heart, Star } from 'lucide-react';
import styles from './LandingPage.module.css';

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className={styles.page}>
      {/* Nav */}
      <nav className={styles.nav}>
        <div className={styles.navBrand}>
          <div className={styles.navLogo}>
            <Heart size={18} fill="currentColor" />
          </div>
          <span className={styles.navName}>MindBridge</span>
        </div>
        <div className={styles.navActions}>
          <button className={styles.navLink} onClick={() => navigate('/admin')}>
            Admin Portal
          </button>
          <button className={styles.navCta} onClick={() => navigate('/chat')}>
            Get Started
          </button>
        </div>
      </nav>

      {/* Hero */}
      <section className={styles.hero}>
        <div className={styles.heroDecor1} />
        <div className={styles.heroDecor2} />
        <div className={styles.heroContent}>
          <div className={styles.heroBadge}>
            <Shield size={13} />
            <span>HIPAA-Compliant Platform</span>
          </div>
          <h1 className={styles.heroTitle}>
            Mental health care,<br />
            <em>matched to you.</em>
          </h1>
          <p className={styles.heroSubtitle}>
            Describe what you're going through. Our AI will find the right therapist, 
            check your insurance, and book your first appointment — in minutes.
          </p>
          <div className={styles.heroActions}>
            <button className={styles.heroCta} onClick={() => navigate('/chat')}>
              Start Matching
              <ArrowRight size={18} />
            </button>
            <button className={styles.heroSecondary} onClick={() => navigate('/admin')}>
              Admin Dashboard
            </button>
          </div>
          <div className={styles.heroStats}>
            <div className={styles.heroStat}>
              <span className={styles.heroStatNum}>500+</span>
              <span className={styles.heroStatLabel}>Patients matched</span>
            </div>
            <div className={styles.heroStatDivider} />
            <div className={styles.heroStat}>
              <span className={styles.heroStatNum}>48</span>
              <span className={styles.heroStatLabel}>Specialist therapists</span>
            </div>
            <div className={styles.heroStatDivider} />
            <div className={styles.heroStat}>
              <span className={styles.heroStatNum}>4.9</span>
              <span className={styles.heroStatLabel}>Average rating</span>
            </div>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <div className={styles.chatPreview}>
            <div className={styles.chatPreviewHeader}>
              <div className={styles.chatPreviewDots}>
                <span /><span /><span />
              </div>
              <span>MindBridge AI</span>
            </div>
            <div className={styles.chatPreviewBody}>
              <div className={styles.previewMsg + ' ' + styles.previewBot}>
                Hello! I'm here to help you find the right therapist. What brings you here today?
              </div>
              <div className={styles.previewMsg + ' ' + styles.previewUser}>
                I've been dealing with anxiety and stress from work…
              </div>
              <div className={styles.previewMsg + ' ' + styles.previewBot}>
                I understand. I'll match you with a therapist who specializes in anxiety and workplace stress. What insurance do you have?
              </div>
              <div className={styles.previewTyping}>
                <span /><span /><span />
              </div>
            </div>
          </div>
          <div className={styles.floatingCard}>
            <div className={styles.floatingCardAvatar}>SM</div>
            <div>
              <div className={styles.floatingCardName}>Dr. Sarah Mitchell</div>
              <div className={styles.floatingCardSpec}>Anxiety · CBT Specialist</div>
            </div>
            <div className={styles.floatingCardBadge}>
              <Star size={11} fill="currentColor" />
              4.9
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className={styles.features}>
        <h2 className={styles.featuresTitle}>How it works</h2>
        <div className={styles.featuresGrid}>
          <div className={styles.featureCard}>
            <div className={styles.featureIcon} style={{ background: 'var(--sage-pale)', color: 'var(--sage-dark)' }}>
              <Heart size={24} />
            </div>
            <h3>Share your story</h3>
            <p>Tell our AI assistant what you're experiencing. No forms, just a natural conversation.</p>
          </div>
          <div className={styles.featureCard}>
            <div className={styles.featureIcon} style={{ background: '#EEF0FF', color: '#5C6AC4' }}>
              <Shield size={24} />
            </div>
            <h3>AI-powered matching</h3>
            <p>We match your needs with therapist specialties and verify your insurance coverage.</p>
          </div>
          <div className={styles.featureCard}>
            <div className={styles.featureIcon} style={{ background: '#FFF5E6', color: '#C97B22' }}>
              <Clock size={24} />
            </div>
            <h3>Instant scheduling</h3>
            <p>Book directly onto your therapist's calendar. Get a confirmation in seconds.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className={styles.footer}>
        <div className={styles.footerBrand}>
          <Heart size={16} fill="currentColor" />
          <span>MindBridge</span>
        </div>
        <p>© 2025 MindBridge Health. All rights reserved.</p>
      </footer>
    </div>
  );
}
