export interface Therapist {
  id: string;
  name: string;
  specialties: string[];
  accepted_insurance: string[];
  bio: string;
  title: string;
  avatar_url?: string;
  google_calendar_id?: string;
  created_at: string;
}

export interface Inquiry {
  id: string;
  patient_identifier: string;
  problem_description: string;
  requested_schedule: string;
  insurance_info: string;
  extracted_specialty?: string;
  matched_therapist_id?: string;
  status: 'pending' | 'matched' | 'scheduled' | 'failed';
  created_at: string;
  therapist?: Therapist;
}

export interface Appointment {
  id: string;
  inquiry_id: string;
  therapist_id: string;
  patient_identifier: string;
  start_time: string;
  end_time: string;
  google_calendar_event_id?: string;
  status: 'confirmed' | 'cancelled' | 'pending';
  created_at: string;
  therapist?: Therapist;
  inquiry?: Inquiry;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
  type?: 'text' | 'therapist-options' | 'booking-confirm' | 'success';
  therapists?: Therapist[];
  appointmentDetails?: {
    therapist: Therapist;
    time: string;
    inquiryId: string;
  };
}

export interface ChatState {
  messages: ChatMessage[];
  isLoading: boolean;
  stage: 'intro' | 'collecting' | 'matching' | 'booking' | 'confirmed';
  inquiryId?: string;
  matchedTherapists?: Therapist[];
  collectedInfo: {
    problem?: string;
    schedule?: string;
    insurance?: string;
    patientName?: string;
    patientEmail?: string;
  };
}
