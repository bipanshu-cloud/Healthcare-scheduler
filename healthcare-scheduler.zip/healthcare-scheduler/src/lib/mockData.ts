import { Therapist, Inquiry, Appointment } from '../types';

export const MOCK_THERAPISTS: Therapist[] = [
  {
    id: '1',
    name: 'Dr. Sarah Mitchell',
    title: 'Licensed Clinical Psychologist',
    specialties: ['anxiety', 'depression', 'trauma', 'PTSD'],
    accepted_insurance: ['aetna', 'bluecross', 'cigna', 'united'],
    bio: 'Dr. Mitchell specializes in cognitive-behavioral therapy with over 12 years helping patients overcome anxiety and trauma. She creates a warm, non-judgmental space for healing.',
    avatar_url: 'SM',
    google_calendar_id: 'sarah.mitchell@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'Dr. James Okonkwo',
    title: 'Marriage & Family Therapist',
    specialties: ['relationships', 'family therapy', 'couples counseling', 'grief'],
    accepted_insurance: ['bluecross', 'humana', 'medicaid', 'aetna'],
    bio: 'With a focus on systemic therapy, Dr. Okonkwo helps families and couples navigate conflict, improve communication, and build stronger bonds through evidence-based approaches.',
    avatar_url: 'JO',
    google_calendar_id: 'james.okonkwo@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '3',
    name: 'Dr. Elena Vasquez',
    title: 'Psychiatrist & Therapist',
    specialties: ['bipolar disorder', 'schizophrenia', 'OCD', 'eating disorders'],
    accepted_insurance: ['united', 'cigna', 'medicare', 'aetna'],
    bio: 'Board-certified psychiatrist combining medication management with psychotherapy. Dr. Vasquez takes a holistic approach to mental wellness and medication optimization.',
    avatar_url: 'EV',
    google_calendar_id: 'elena.vasquez@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '4',
    name: 'Dr. Marcus Chen',
    title: 'Adolescent & Child Psychologist',
    specialties: ['ADHD', 'autism', 'childhood trauma', 'learning disabilities'],
    accepted_insurance: ['bluecross', 'aetna', 'humana', 'tricare'],
    bio: 'Dedicated to helping children and adolescents thrive, Dr. Chen uses play therapy and family-centered approaches to address developmental and behavioral challenges.',
    avatar_url: 'MC',
    google_calendar_id: 'marcus.chen@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '5',
    name: 'Dr. Priya Sharma',
    title: 'Clinical Social Worker',
    specialties: ['substance abuse', 'addiction', 'life transitions', 'stress management'],
    accepted_insurance: ['medicaid', 'medicare', 'cigna', 'humana'],
    bio: 'Dr. Sharma brings compassion and evidence-based practice to addiction and recovery. She specializes in motivational interviewing and harm reduction strategies.',
    avatar_url: 'PS',
    google_calendar_id: 'priya.sharma@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
];

export const MOCK_INQUIRIES: Inquiry[] = [
  {
    id: 'inq-1',
    patient_identifier: 'patient-hash-001',
    problem_description: 'I have been experiencing severe anxiety and panic attacks for the past 3 months, especially at work.',
    requested_schedule: 'Weekday evenings after 6pm',
    insurance_info: 'Aetna',
    extracted_specialty: 'anxiety',
    matched_therapist_id: '1',
    status: 'scheduled',
    created_at: '2025-04-15T14:22:00Z',
    therapist: MOCK_THERAPISTS[0],
  },
  {
    id: 'inq-2',
    patient_identifier: 'patient-hash-002',
    problem_description: 'My husband and I have been having communication issues and we feel disconnected.',
    requested_schedule: 'Saturday mornings',
    insurance_info: 'BlueCross',
    extracted_specialty: 'couples counseling',
    matched_therapist_id: '2',
    status: 'matched',
    created_at: '2025-04-16T09:45:00Z',
    therapist: MOCK_THERAPISTS[1],
  },
  {
    id: 'inq-3',
    patient_identifier: 'patient-hash-003',
    problem_description: 'Struggling with grief after losing my mother last year. Finding it hard to function.',
    requested_schedule: 'Flexible',
    insurance_info: 'Humana',
    extracted_specialty: 'grief',
    matched_therapist_id: '2',
    status: 'pending',
    created_at: '2025-04-18T11:30:00Z',
  },
  {
    id: 'inq-4',
    patient_identifier: 'patient-hash-004',
    problem_description: 'My 10-year-old son has been diagnosed with ADHD and we need help managing his behavior.',
    requested_schedule: 'After school, 3-5pm',
    insurance_info: 'BlueCross',
    extracted_specialty: 'ADHD',
    matched_therapist_id: '4',
    status: 'scheduled',
    created_at: '2025-04-19T16:00:00Z',
    therapist: MOCK_THERAPISTS[3],
  },
  {
    id: 'inq-5',
    patient_identifier: 'patient-hash-005',
    problem_description: 'Going through a difficult career transition and feeling lost about my identity and purpose.',
    requested_schedule: 'Any weekday',
    insurance_info: 'Cigna',
    extracted_specialty: 'life transitions',
    matched_therapist_id: '5',
    status: 'matched',
    created_at: '2025-04-20T08:15:00Z',
    therapist: MOCK_THERAPISTS[4],
  },
];

export const MOCK_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-1',
    inquiry_id: 'inq-1',
    therapist_id: '1',
    patient_identifier: 'patient-hash-001',
    start_time: '2025-04-22T18:00:00Z',
    end_time: '2025-04-22T19:00:00Z',
    google_calendar_event_id: 'gcal-event-001',
    status: 'confirmed',
    created_at: '2025-04-15T14:30:00Z',
    therapist: MOCK_THERAPISTS[0],
    inquiry: MOCK_INQUIRIES[0],
  },
  {
    id: 'apt-2',
    inquiry_id: 'inq-4',
    therapist_id: '4',
    patient_identifier: 'patient-hash-004',
    start_time: '2025-04-23T15:00:00Z',
    end_time: '2025-04-23T16:00:00Z',
    status: 'confirmed',
    created_at: '2025-04-19T16:30:00Z',
    therapist: MOCK_THERAPISTS[3],
    inquiry: MOCK_INQUIRIES[3],
  },
  {
    id: 'apt-3',
    inquiry_id: 'inq-2',
    therapist_id: '2',
    patient_identifier: 'patient-hash-002',
    start_time: '2025-04-26T10:00:00Z',
    end_time: '2025-04-26T11:00:00Z',
    status: 'confirmed',
    created_at: '2025-04-16T10:00:00Z',
    therapist: MOCK_THERAPISTS[1],
    inquiry: MOCK_INQUIRIES[1],
  },
];

// AI matching logic (simulated)
export function matchTherapists(problem: string, insurance: string): Therapist[] {
  const problemLower = problem.toLowerCase();
  const insuranceLower = insurance.toLowerCase();
  
  const scored = MOCK_THERAPISTS.map(t => {
    let score = 0;
    // Check specialty match
    t.specialties.forEach(s => {
      if (problemLower.includes(s.toLowerCase())) score += 3;
    });
    // Check keyword matches
    if (problemLower.includes('anxious') || problemLower.includes('anxiety') || problemLower.includes('panic')) {
      if (t.specialties.includes('anxiety')) score += 5;
    }
    if (problemLower.includes('depress') || problemLower.includes('sad') || problemLower.includes('hopeless')) {
      if (t.specialties.includes('depression')) score += 5;
    }
    if (problemLower.includes('relationship') || problemLower.includes('marriage') || problemLower.includes('couple') || problemLower.includes('partner')) {
      if (t.specialties.includes('couples counseling')) score += 5;
    }
    if (problemLower.includes('grief') || problemLower.includes('loss') || problemLower.includes('death') || problemLower.includes('mourn')) {
      if (t.specialties.includes('grief')) score += 5;
    }
    if (problemLower.includes('child') || problemLower.includes('kid') || problemLower.includes('adhd') || problemLower.includes('teen')) {
      if (t.specialties.includes('ADHD') || t.specialties.includes('childhood trauma')) score += 5;
    }
    if (problemLower.includes('trauma') || problemLower.includes('ptsd') || problemLower.includes('abuse')) {
      if (t.specialties.includes('trauma') || t.specialties.includes('PTSD')) score += 5;
    }
    if (problemLower.includes('addiction') || problemLower.includes('substance') || problemLower.includes('alcohol') || problemLower.includes('drug')) {
      if (t.specialties.includes('substance abuse')) score += 5;
    }
    // Insurance match
    if (t.accepted_insurance.some(ins => insuranceLower.includes(ins.toLowerCase()))) score += 2;
    
    return { therapist: t, score };
  });

  return scored
    .filter(s => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(s => s.therapist);
}
