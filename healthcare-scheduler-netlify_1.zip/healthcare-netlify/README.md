# MindBridge — AI Healthcare Patient Scheduling

A full-stack healthcare chatbot that matches patients with therapists using AI, books appointments on Google Calendar, and provides an admin dashboard.

## 🚀 Deploy to Netlify

### Option 1: Drag & Drop (Quickest)
1. Run `npm install && npm run build` locally
2. Drag the `dist/` folder to [netlify.com/drop](https://app.netlify.com/drop)

### Option 2: Git Deploy (Recommended)
1. Push this project to GitHub
2. Connect repo at [app.netlify.com](https://app.netlify.com)
3. Build settings are auto-detected from `netlify.toml`

### Option 3: Netlify CLI
```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

## 🔧 Environment Variables (Optional)
Set these in Netlify → Site Settings → Environment Variables for real Supabase:
```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

Without these, the app runs in **demo mode** with mock data.

## 🎮 Demo Credentials
- **Admin Portal**: admin@mindbridge.health / demo1234
- **Chat**: Just visit /chat and type naturally

## 🏗️ Tech Stack
- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: CSS Modules
- **Backend**: Supabase (PostgreSQL + Edge Functions)
- **AI**: OpenAI / Anthropic / Gemini (via Edge Functions)
- **Calendar**: Google Calendar API

## 📁 Project Structure
```
src/
├── pages/          # LandingPage, ChatPage, AdminPage
├── components/     # TherapistCard, BookingModal
├── lib/            # Supabase client, mock data
└── types/          # TypeScript interfaces

supabase/
├── functions/      # Edge Functions (handle-chat, find-therapist, etc.)
└── migrations/     # Database schema
```

## 🗄️ Supabase Setup
Run `/supabase/migrations/001_init_schema.sql` in your Supabase SQL Editor to create tables.
Then deploy edge functions: `supabase functions deploy`
