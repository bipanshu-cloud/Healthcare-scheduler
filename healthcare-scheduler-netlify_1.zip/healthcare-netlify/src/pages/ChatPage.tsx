import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Heart, Calendar, CheckCircle, Loader2, User, Sparkles } from 'lucide-react';
import { ChatMessage, ChatState, Therapist } from '../types';
import {
  MOCK_THERAPISTS, matchTherapists,
  findTherapistByName, isSlotAvailable, getNextAvailableSlots,
  getAvailableSlotsForTherapist,
  formatHour, formatDate, answerGeneralQuestion,
  parseDateFromText, parseTimeFromText,
} from '../lib/mockData';
import TherapistCard from '../components/TherapistCard';
import BookingModal from '../components/BookingModal';
import styles from './ChatPage.module.css';

const INSURANCE_OPTIONS = ['Aetna', 'BlueCross BlueShield', 'Cigna', 'Humana', 'United Healthcare', 'Medicaid', 'Medicare', 'Tricare', 'Self-pay'];

function generateId() { return Math.random().toString(36).substr(2, 9); }
function botMsg(text: string, extras?: Partial<ChatMessage>): ChatMessage {
  return { id: generateId(), sender: 'bot', text, timestamp: new Date(), ...extras };
}

const BOT_INTRO = `Hello! I'm the MindBridge AI assistant. 🌿

I'm here to help you find and book the right therapist — quickly and confidentially.

Here's what I can do:
• **Match you** with the best therapist for your needs
• **Book directly** — just say *"Book with Dr. Mitchell at 3pm tomorrow"*
• **Check availability** — e.g., *"Is Dr. Chen free on Friday at 2pm?"*
• **Answer any questions** about our services, insurance, pricing, and more

What would you like to do today?`;

interface PendingBooking {
  therapist: Therapist;
  date: string;
  hour: number;
}

export default function ChatPage() {
  const navigate = useNavigate();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [input, setInput] = useState('');
  const [bookingModal, setBookingModal] = useState<Therapist | null>(null);
  const [pendingBooking, setPendingBooking] = useState<PendingBooking | null>(null);
  const [state, setState] = useState<ChatState>({
    messages: [botMsg(BOT_INTRO)],
    isLoading: false,
    stage: 'intro',
    collectedInfo: {},
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.messages, state.isLoading]);

  const addMessage = (msg: ChatMessage) =>
    setState(prev => ({ ...prev, messages: [...prev.messages, msg] }));

  const addBot = (text: string, extras?: Partial<ChatMessage>) => addMessage(botMsg(text, extras));

  const typing = (fn: () => void, delay = 900) => {
    setState(prev => ({ ...prev, isLoading: true }));
    setTimeout(() => {
      setState(prev => ({ ...prev, isLoading: false }));
      fn();
    }, delay);
  };

  // ─── Main message processor ────────────────────────────────────────────────
  const processMessage = (text: string) => {
    const lower = text.toLowerCase();
    const { stage, collectedInfo } = state;

    // 1. Check for general Q&A first — always works regardless of stage
    const generalAnswer = answerGeneralQuestion(text);
    if (generalAnswer && stage !== 'collecting') {
      typing(() => addBot(generalAnswer));
      return;
    }

    // 2. DIRECT BOOKING — "book with Dr. X at Y time on Z date"
    const mentionedTherapist = MOCK_THERAPISTS.find(t => {
      const tl = t.name.toLowerCase();
      const last = tl.split(' ').pop() || '';
      return lower.includes(tl) || lower.includes(last);
    });

    const requestedDate = parseDateFromText(lower);
    const requestedHour = parseTimeFromText(lower);

    const isBookingRequest = /book|schedule|appointment|session|reserve|want to see|can i (get|see|meet)|i want/.test(lower);
    const isAvailabilityCheck = /available|availability|free|open|when can|check/.test(lower);

    if (mentionedTherapist && (isBookingRequest || requestedHour || requestedDate)) {
      handleDirectBookingRequest(mentionedTherapist, requestedDate, requestedHour, text);
      return;
    }

    if (mentionedTherapist && isAvailabilityCheck) {
      handleAvailabilityCheck(mentionedTherapist, requestedDate, requestedHour);
      return;
    }

    // 3. PENDING BOOKING CONFIRMATION
    if (pendingBooking) {
      const yes = /^(yes|yeah|yep|sure|ok|okay|confirm|book it|sounds good|perfect|great|please|go ahead|do it|yes please)\b/i.test(lower);
      const no = /^(no|nope|cancel|nevermind|never mind|different|other|another)\b/i.test(lower);
      if (yes) {
        confirmPendingBooking();
        return;
      }
      if (no) {
        setPendingBooking(null);
        typing(() => addBot(`No problem! Would you like to:\n• Pick a different time with **${pendingBooking.therapist.name}**\n• Choose a different therapist\n• Or tell me what you're looking for and I'll match you?\n\nJust let me know! 😊`));
        return;
      }
    }

    // 4. FLOW-BASED CONVERSATION (problem → schedule → insurance → match)
    if (stage === 'intro' || (stage === 'collecting' && !collectedInfo.problem)) {
      // If it seems like they're describing a problem
      if (text.length > 10 || /feel|going through|dealing|struggle|help|need|problem|issue|anxiety|depress|stress|grief|trauma|relationship/.test(lower)) {
        setState(prev => ({ ...prev, stage: 'collecting', collectedInfo: { problem: text } }));
        typing(() => {
          addBot(`Thank you for sharing that with me. It takes real courage to reach out, and I want you to know you're in the right place. 💚\n\nTo find the best therapist for you — do you have a preference for when you'd like to meet?\n\nFor example: *weekday evenings*, *weekend mornings*, or just say *flexible* if any time works.`);
        });
        return;
      }
      // General chitchat
      typing(() => addBot(`I'm here and ready to help! 😊\n\nYou can:\n• Tell me what you're going through and I'll match you with the right therapist\n• Ask me to book with a specific doctor directly\n• Ask any questions about our services\n\nWhat would you like to do?`));
      return;
    }

    if (stage === 'collecting' && collectedInfo.problem && !collectedInfo.schedule) {
      setState(prev => ({ ...prev, collectedInfo: { ...prev.collectedInfo, schedule: text } }));
      typing(() => {
        addBot(`Perfect! One more thing — what health insurance do you have? This helps me find therapists who are in-network for you.\n\nYou can type your provider or pick from the options below.`);
        setTimeout(() => addBot('__INSURANCE_OPTIONS__'), 200);
      });
      return;
    }

    if (stage === 'collecting' && collectedInfo.problem && collectedInfo.schedule && !collectedInfo.insurance) {
      const insurance = text;
      setState(prev => ({ ...prev, collectedInfo: { ...prev.collectedInfo, insurance }, stage: 'matching' }));
      typing(() => addBot(`Great! Searching for therapists who specialize in what you've described and accept **${insurance}**... 🔍`), 600);
      setTimeout(() => {
        const matches = matchTherapists(collectedInfo.problem || '', insurance);
        const show = matches.length > 0 ? matches : MOCK_THERAPISTS.slice(0, 3);
        typing(() => {
          addBot(
            `I found **${show.length} therapist${show.length > 1 ? 's' : ''}** who are an excellent match for you! Here are your options:`,
            { type: 'therapist-options', therapists: show }
          );
          setState(prev => ({ ...prev, matchedTherapists: show }));
        }, 1200);
      }, 1400);
      return;
    }

    if (stage === 'matching' || stage === 'confirmed') {
      // After matching, answer any question or handle re-booking
      const general = answerGeneralQuestion(text);
      if (general) {
        typing(() => addBot(general));
        return;
      }
      typing(() => addBot(`I'm here to help! You can:\n• Click **Book with** on any therapist card above\n• Say something like *"Book with Dr. Mitchell at 3pm tomorrow"*\n• Ask me any other questions 😊`));
      return;
    }

    // Fallback — be conversational
    typing(() => {
      const fallbacks = [
        `I'm not quite sure I understood that. Could you rephrase? You can also ask me things like:\n• *"What insurance do you accept?"*\n• *"Book with Dr. Mitchell at 2pm Friday"*\n• *"Who are your therapists?"*`,
        `That's a bit outside what I can help with directly, but I'm happy to help you find and book a therapist! What are you looking for?`,
        `Let me help you the best I can! Try asking me about booking an appointment, checking availability, or tell me what you're going through and I'll find the right match.`,
      ];
      addBot(fallbacks[Math.floor(Math.random() * fallbacks.length)]);
    });
  };

  // ─── Direct booking request handler ───────────────────────────────────────
  const handleDirectBookingRequest = (
    therapist: Therapist,
    date: string | null,
    hour: number | null,
    originalText: string
  ) => {
    // Case 1: Both date and time provided — check availability immediately
    if (date && hour) {
      typing(() => {
        const available = isSlotAvailable(therapist.id, date, hour);
        if (available) {
          setPendingBooking({ therapist, date, hour });
          addBot(
            `✅ Good news! **${therapist.name}** is available on **${formatDate(date)}** at **${formatHour(hour)}**.\n\nShall I confirm this booking for you?`,
            { type: 'text' }
          );
        } else {
          // Not available — show alternatives
          const altSlots = getNextAvailableSlots(therapist.id, 4);
          const altList = altSlots.map(s => `• **${formatDate(s.date)}** at **${formatHour(s.hour)}**`).join('\n');
          addBot(
            `❌ Sorry, **${therapist.name}** is **not available** on ${formatDate(date)} at ${formatHour(hour)}.\n\nHere are the next available slots with ${therapist.name}:\n\n${altList}\n\nJust tell me which one works for you! 😊`,
            { type: 'slot-alternatives', therapist, altSlots } as any
          );
        }
      });
      return;
    }

    // Case 2: Only date provided — show available times that day
    if (date && !hour) {
      typing(() => {
        const slots = getAvailableSlotsForTherapist(therapist.id, date);
        if (slots.length === 0) {
          const altSlots = getNextAvailableSlots(therapist.id, 4);
          const altList = altSlots.map(s => `• **${formatDate(s.date)}** at **${formatHour(s.hour)}**`).join('\n');
          addBot(`❌ **${therapist.name}** has no available slots on **${formatDate(date)}**.\n\nNext available times:\n\n${altList}\n\nWhich works for you?`);
        } else {
          const slotList = slots.map((h: number) => formatHour(h)).join(' · ');
          addBot(`📅 **${therapist.name}** is available on **${formatDate(date)}** at:\n\n${slotList}\n\nWhich time would you like?`);
          setState(prev => ({ ...prev, collectedInfo: { ...prev.collectedInfo, pendingTherapistId: therapist.id, pendingDate: date } as any }));
        }
      });
      return;
    }

    // Case 3: Only time provided — find next date with that slot available
    if (!date && hour) {
      typing(() => {
        // Find next available date at that hour
        let found: string | null = null;
        const d = new Date();
        d.setDate(d.getDate() + 1);
        for (let i = 0; i < 14; i++) {
          if (d.getDay() !== 0 && d.getDay() !== 6) {
            const ds = d.toISOString().split('T')[0];
            if (isSlotAvailable(therapist.id, ds, hour)) {
              found = ds;
              break;
            }
          }
          d.setDate(d.getDate() + 1);
        }
        if (found) {
          setPendingBooking({ therapist, date: found, hour });
          addBot(`✅ **${therapist.name}** is available at **${formatHour(hour)}** on **${formatDate(found)}**.\n\nShall I confirm this booking?`);
        } else {
          const altSlots = getNextAvailableSlots(therapist.id, 4);
          const altList = altSlots.map(s => `• **${formatDate(s.date)}** at **${formatHour(s.hour)}**`).join('\n');
          addBot(`❌ **${therapist.name}** doesn't have ${formatHour(hour)} available in the next 2 weeks.\n\nNext available slots:\n\n${altList}\n\nWhich works for you?`);
        }
      });
      return;
    }

    // Case 4: Only therapist name — open booking modal
    typing(() => {
      addBot(`Sure! Let me bring up the booking calendar for **${therapist.name}**. 📅`);
      setTimeout(() => setBookingModal(therapist), 600);
    });
  };

  // ─── Availability check handler ────────────────────────────────────────────
  const handleAvailabilityCheck = (
    therapist: Therapist,
    date: string | null,
    hour: number | null
  ) => {
    typing(() => {
      if (date && hour) {
        const avail = isSlotAvailable(therapist.id, date, hour);
        if (avail) {
          setPendingBooking({ therapist, date, hour });
          addBot(`✅ Yes! **${therapist.name}** is **available** on ${formatDate(date)} at ${formatHour(hour)}.\n\nWould you like me to book this slot for you?`);
        } else {
          const altSlots = getNextAvailableSlots(therapist.id, 4);
          const altList = altSlots.map(s => `• **${formatDate(s.date)}** at **${formatHour(s.hour)}**`).join('\n');
          addBot(`❌ **${therapist.name}** is **not available** on ${formatDate(date)} at ${formatHour(hour)}.\n\nHere are the next available slots:\n\n${altList}\n\nWould any of these work for you?`);
        }
      } else if (date) {
        const slots = getAvailableSlotsForTherapist(therapist.id, date);
        if (slots.length === 0) {
          addBot(`**${therapist.name}** has no available slots on ${formatDate(date)}. Would you like me to check other dates?`);
        } else {
          addBot(`📅 **${therapist.name}** is available on **${formatDate(date)}** at:\n\n${slots.map((h: number) => `• ${formatHour(h)}`).join('\n')}\n\nWhich time would you like to book?`);
        }
      } else {
        const altSlots = getNextAvailableSlots(therapist.id, 6);
        const altList = altSlots.map(s => `• **${formatDate(s.date)}** at **${formatHour(s.hour)}**`).join('\n');
        addBot(`📅 Here are the next available slots for **${therapist.name}**:\n\n${altList}\n\nWhich one works for you?`);
      }
    });
  };

  // ─── Confirm a pending booking (after user says "yes") ────────────────────
  const confirmPendingBooking = () => {
    if (!pendingBooking) return;
    const { therapist, date, hour } = pendingBooking;
    typing(() => {
      addBot(
        `🎉 **Appointment Confirmed!**\n\n👨‍⚕️ **${therapist.name}**\n📅 **${formatDate(date)}**\n🕐 **${formatHour(hour)}** (50 minutes)\n📧 Confirmation sent to your email\n📲 Added to ${therapist.name}'s Google Calendar\n\nIs there anything else I can help you with?`,
        { type: 'success' }
      );
      setState(prev => ({ ...prev, stage: 'confirmed' }));
      setPendingBooking(null);
    }, 1000);
  };

  // ─── Slot alternative click ─────────────────────────────────────────────────
  const handleSlotClick = (therapist: Therapist, date: string, hour: number) => {
    addMessage({ id: generateId(), sender: 'user', text: `I'll take ${formatDate(date)} at ${formatHour(hour)}`, timestamp: new Date() });
    setPendingBooking({ therapist, date, hour });
    typing(() => {
      addBot(`✅ Great choice! **${formatDate(date)}** at **${formatHour(hour)}** with **${therapist.name}**.\n\nShall I confirm this booking?`);
    }, 600);
  };

  const handleSend = () => {
    const trimmed = input.trim();
    if (!trimmed || state.isLoading) return;
    setInput('');
    addMessage({ id: generateId(), sender: 'user', text: trimmed, timestamp: new Date() });
    processMessage(trimmed);
  };

  const handleQuickReply = (option: string) => {
    setState(prev => ({ ...prev, messages: prev.messages.filter(m => m.text !== '__INSURANCE_OPTIONS__') }));
    addMessage({ id: generateId(), sender: 'user', text: option, timestamp: new Date() });
    processMessage(option);
  };

  const handleBookingConfirm = (therapist: Therapist, timeSlot: string) => {
    setBookingModal(null);
    addMessage({ id: generateId(), sender: 'user', text: `Book with ${therapist.name} — ${timeSlot}`, timestamp: new Date() });
    typing(() => {
      addBot(
        `🎉 **Appointment Confirmed!**\n\n👨‍⚕️ **${therapist.name}**\n🕐 **${timeSlot}**\n📧 Confirmation sent to your email\n📲 Added to ${therapist.name}'s Google Calendar\n\nIs there anything else I can help you with?`,
        { type: 'success' }
      );
      setState(prev => ({ ...prev, stage: 'confirmed' }));
    }, 1200);
  };

  const renderMessageText = (text: string) => {
    return text.split('\n').map((line, i, arr) => {
      const formatted = line
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>');
      return (
        <span key={i}>
          <span dangerouslySetInnerHTML={{ __html: formatted }} />
          {i < arr.length - 1 && <br />}
        </span>
      );
    });
  };

  return (
    <div className={styles.page}>
      {/* Header */}
      <header className={styles.header}>
        <button className={styles.backBtn} onClick={() => navigate('/')}>
          <ArrowLeft size={18} />
        </button>
        <div className={styles.headerBrand}>
          <div className={styles.headerAvatar}><Sparkles size={16} /></div>
          <div>
            <div className={styles.headerTitle}>MindBridge AI</div>
            <div className={styles.headerStatus}>
              <span className={styles.statusDot} />
              Available now · Ask me anything
            </div>
          </div>
        </div>
        <button className={styles.calendarBtn} onClick={() => navigate('/admin')}>
          <Calendar size={18} /><span>Admin</span>
        </button>
      </header>

      {/* Messages */}
      <div className={styles.messages}>
        <div className={styles.messagesInner}>
          {state.messages.map((msg, i) => {
            // Insurance quick-replies
            if (msg.text === '__INSURANCE_OPTIONS__') {
              return (
                <div key={msg.id} className={styles.quickReplies}>
                  {INSURANCE_OPTIONS.map(opt => (
                    <button key={opt} className={styles.quickReply} onClick={() => handleQuickReply(opt)}>
                      {opt}
                    </button>
                  ))}
                </div>
              );
            }

            // Slot alternatives inline
            const extras = msg as any;
            const hasAltSlots = extras.altSlots && extras.therapist;

            return (
              <div
                key={msg.id}
                className={`${styles.msgWrapper} ${msg.sender === 'user' ? styles.userWrapper : styles.botWrapper}`}
                style={{ animationDelay: `${Math.min(i, 6) * 0.05}s` }}
              >
                {msg.sender === 'bot' && (
                  <div className={styles.botAvatar}><Heart size={12} fill="currentColor" /></div>
                )}
                <div className={`${styles.bubble} ${msg.sender === 'user' ? styles.userBubble : styles.botBubble} ${msg.type === 'success' ? styles.successBubble : ''}`}>
                  {msg.type === 'success' && <div className={styles.successIcon}><CheckCircle size={20} /></div>}
                  <div className={styles.msgText}>{renderMessageText(msg.text)}</div>

                  {/* Therapist match cards */}
                  {msg.type === 'therapist-options' && msg.therapists && (
                    <div className={styles.therapistOptions}>
                      {msg.therapists.map(t => (
                        <TherapistCard key={t.id} therapist={t} onSelect={() => setBookingModal(t)} />
                      ))}
                    </div>
                  )}

                  {/* Slot alternative buttons */}
                  {hasAltSlots && (
                    <div className={styles.slotAlts}>
                      {extras.altSlots.map((s: { date: string; hour: number }, idx: number) => (
                        <button
                          key={idx}
                          className={styles.slotAltBtn}
                          onClick={() => handleSlotClick(extras.therapist, s.date, s.hour)}
                        >
                          📅 {formatDate(s.date)} · {formatHour(s.hour)}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Pending booking confirm/cancel */}
                  {pendingBooking && i === state.messages.length - 1 && msg.sender === 'bot' && !msg.type && (
                    <div className={styles.confirmRow}>
                      <button className={styles.confirmYes} onClick={confirmPendingBooking}>
                        <CheckCircle size={15} /> Yes, confirm!
                      </button>
                      <button className={styles.confirmNo} onClick={() => {
                        setPendingBooking(null);
                        typing(() => addBot(`No problem! Would you like a different time or a different therapist?`), 400);
                      }}>
                        No, change it
                      </button>
                    </div>
                  )}
                </div>
                {msg.sender === 'user' && (
                  <div className={styles.userAvatar}><User size={14} /></div>
                )}
              </div>
            );
          })}

          {state.isLoading && (
            <div className={`${styles.msgWrapper} ${styles.botWrapper}`}>
              <div className={styles.botAvatar}><Heart size={12} fill="currentColor" /></div>
              <div className={`${styles.bubble} ${styles.botBubble}`}>
                <div className={styles.typingIndicator}><span /><span /><span /></div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className={styles.inputArea}>
        <div className={styles.inputRow}>
          <input
            ref={inputRef}
            className={styles.input}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder='Ask anything — e.g. "Book Dr. Mitchell at 3pm tomorrow"'
            disabled={state.isLoading}
          />
          <button className={styles.sendBtn} onClick={handleSend} disabled={!input.trim() || state.isLoading}>
            {state.isLoading ? <Loader2 size={18} className={styles.spinner} /> : <Send size={18} />}
          </button>
        </div>
        <div className={styles.inputFooter}>
          <span>🔒 Confidential & secure</span>
          <span>·</span>
          <span>Not a crisis service — call 911 if in immediate danger</span>
        </div>
      </div>

      {bookingModal && (
        <BookingModal
          therapist={bookingModal}
          preferredSchedule={state.collectedInfo.schedule}
          onConfirm={handleBookingConfirm}
          onClose={() => setBookingModal(null)}
        />
      )}
    </div>
  );
}
