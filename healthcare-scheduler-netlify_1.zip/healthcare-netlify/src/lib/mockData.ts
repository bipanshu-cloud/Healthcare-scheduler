import { Therapist, Inquiry, Appointment } from '../types';

export const MOCK_THERAPISTS: Therapist[] = [
  {
    id: '1',
    name: 'Dr. Sarah Mitchell',
    title: 'Licensed Clinical Psychologist',
    specialties: ['anxiety', 'depression', 'trauma', 'PTSD', 'stress'],
    accepted_insurance: ['aetna', 'bluecross', 'cigna', 'united'],
    bio: 'Dr. Mitchell specializes in cognitive-behavioral therapy with over 12 years helping patients overcome anxiety and trauma. She creates a warm, non-judgmental space for healing.',
    avatar_url: 'SM',
    google_calendar_id: 'sarah.mitchell@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'Dr. James Okonkwo',
    title: 'Marriage & Family Therapist',
    specialties: ['relationships', 'family therapy', 'couples counseling', 'grief', 'depression'],
    accepted_insurance: ['bluecross', 'humana', 'medicaid', 'aetna'],
    bio: 'With a focus on systemic therapy, Dr. Okonkwo helps families and couples navigate conflict, improve communication, and build stronger bonds through evidence-based approaches.',
    avatar_url: 'JO',
    google_calendar_id: 'james.okonkwo@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '3',
    name: 'Dr. Elena Vasquez',
    title: 'Psychiatrist & Therapist',
    specialties: ['bipolar disorder', 'schizophrenia', 'OCD', 'eating disorders', 'anxiety'],
    accepted_insurance: ['united', 'cigna', 'medicare', 'aetna'],
    bio: 'Board-certified psychiatrist combining medication management with psychotherapy. Dr. Vasquez takes a holistic approach to mental wellness and medication optimization.',
    avatar_url: 'EV',
    google_calendar_id: 'elena.vasquez@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '4',
    name: 'Dr. Marcus Chen',
    title: 'Adolescent & Child Psychologist',
    specialties: ['ADHD', 'autism', 'childhood trauma', 'learning disabilities', 'anxiety'],
    accepted_insurance: ['bluecross', 'aetna', 'humana', 'tricare'],
    bio: 'Dedicated to helping children and adolescents thrive, Dr. Chen uses play therapy and family-centered approaches to address developmental and behavioral challenges.',
    avatar_url: 'MC',
    google_calendar_id: 'marcus.chen@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '5',
    name: 'Dr. Priya Sharma',
    title: 'Clinical Social Worker',
    specialties: ['substance abuse', 'addiction', 'life transitions', 'stress management', 'depression'],
    accepted_insurance: ['medicaid', 'medicare', 'cigna', 'humana'],
    bio: 'Dr. Sharma brings compassion and evidence-based practice to addiction and recovery. She specializes in motivational interviewing and harm reduction strategies.',
    avatar_url: 'PS',
    google_calendar_id: 'priya.sharma@mindbridge.health',
    created_at: '2024-01-01T00:00:00Z',
  },
];

// ─── Slot Availability System ─────────────────────────────────────────────────

function getFutureWeekday(daysAhead: number): string {
  const d = new Date();
  d.setDate(d.getDate() + daysAhead);
  while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() + 1);
  return d.toISOString().split('T')[0];
}

const BOOKED_SLOTS: Record<string, Record<string, number[]>> = {
  '1': {
    [getFutureWeekday(1)]: [9, 10, 14, 15],
    [getFutureWeekday(2)]: [9, 11, 16],
    [getFutureWeekday(3)]: [10, 13, 15],
    [getFutureWeekday(4)]: [9, 10, 11, 14],
  },
  '2': {
    [getFutureWeekday(1)]: [10, 11, 15],
    [getFutureWeekday(2)]: [9, 14, 16, 17],
    [getFutureWeekday(3)]: [9, 10, 11],
  },
  '3': {
    [getFutureWeekday(1)]: [9, 10, 11, 14, 15, 16],
    [getFutureWeekday(2)]: [9, 10],
    [getFutureWeekday(4)]: [14, 15, 16, 17],
  },
  '4': {
    [getFutureWeekday(2)]: [9, 10, 15],
    [getFutureWeekday(3)]: [14, 15, 16],
  },
  '5': {
    [getFutureWeekday(1)]: [9, 11, 14],
    [getFutureWeekday(3)]: [10, 11, 15, 16],
    [getFutureWeekday(5)]: [9, 10, 11, 14, 15],
  },
};

export const ALL_HOURS = [9, 10, 11, 13, 14, 15, 16, 17];

export function getAvailableSlotsForTherapist(therapistId: string, dateStr: string): number[] {
  const booked = BOOKED_SLOTS[therapistId]?.[dateStr] || [];
  return ALL_HOURS.filter(h => !booked.includes(h));
}

export function isSlotAvailable(therapistId: string, dateStr: string, hour: number): boolean {
  const booked = BOOKED_SLOTS[therapistId]?.[dateStr] || [];
  return !booked.includes(hour);
}

export function getNextAvailableSlots(therapistId: string, count = 4): { date: string; hour: number }[] {
  const results: { date: string; hour: number }[] = [];
  const d = new Date();
  d.setDate(d.getDate() + 1);
  let attempts = 0;
  while (results.length < count && attempts < 30) {
    attempts++;
    if (d.getDay() !== 0 && d.getDay() !== 6) {
      const dateStr = d.toISOString().split('T')[0];
      const slots = getAvailableSlotsForTherapist(therapistId, dateStr);
      for (const slot of slots.slice(0, 2)) {
        if (results.length < count) results.push({ date: dateStr, hour: slot });
      }
    }
    d.setDate(d.getDate() + 1);
  }
  return results;
}

export function formatHour(hour: number): string {
  if (hour === 12) return '12:00 PM';
  if (hour < 12) return `${hour}:00 AM`;
  return `${hour - 12}:00 PM`;
}

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr + 'T12:00:00');
  return d.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
}

export function parseTimeFromText(text: string): number | null {
  const lower = text.toLowerCase();
  const ampm = lower.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/i);
  if (ampm) {
    let hour = parseInt(ampm[1]);
    const mer = ampm[3].toLowerCase();
    if (mer === 'pm' && hour !== 12) hour += 12;
    if (mer === 'am' && hour === 12) hour = 0;
    if (hour >= 9 && hour <= 19) return hour;
  }
  const clock = lower.match(/\b(\d{1,2})\s*o'?clock\b/i);
  if (clock) {
    let hour = parseInt(clock[1]);
    if (hour < 9) hour += 12;
    if (hour >= 9 && hour <= 19) return hour;
  }
  const time24 = lower.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
  if (time24) {
    const hour = parseInt(time24[1]);
    if (hour >= 9 && hour <= 19) return hour;
  }
  if (/\b9\b/.test(lower) && /morning/.test(lower)) return 9;
  if (/afternoon/.test(lower)) return 14;
  if (/evening/.test(lower)) return 17;
  return null;
}

export function parseDateFromText(text: string): string | null {
  const lower = text.toLowerCase();
  const today = new Date();

  if (/\btoday\b/.test(lower)) {
    return today.toISOString().split('T')[0];
  }
  if (/\btomorrow\b/.test(lower)) {
    const d = new Date(today);
    d.setDate(d.getDate() + 1);
    while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  }

  const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  for (let i = 0; i < dayNames.length; i++) {
    if (lower.includes(dayNames[i])) {
      const d = new Date(today);
      let diff = i - d.getDay();
      if (diff <= 0) diff += 7;
      d.setDate(d.getDate() + diff);
      return d.toISOString().split('T')[0];
    }
  }

  const monthNames = ['january','february','march','april','may','june','july','august','september','october','november','december'];
  for (let mi = 0; mi < monthNames.length; mi++) {
    if (lower.includes(monthNames[mi])) {
      const dayMatch = lower.match(/\b(\d{1,2})\b/);
      if (dayMatch) {
        const year = today.getFullYear();
        const d = new Date(year, mi, parseInt(dayMatch[1]));
        if (d <= today) d.setFullYear(year + 1);
        return d.toISOString().split('T')[0];
      }
    }
  }
  return null;
}

export function findTherapistByName(name: string): Therapist | null {
  const lower = name.toLowerCase();
  return MOCK_THERAPISTS.find(t => {
    const tLower = t.name.toLowerCase();
    const lastName = tLower.split(' ').pop() || '';
    return tLower.includes(lower) || lower.includes(lastName) || lower.includes(tLower);
  }) || null;
}

export function matchTherapists(problem: string, insurance: string): Therapist[] {
  const pl = problem.toLowerCase();
  const il = insurance.toLowerCase();
  const scored = MOCK_THERAPISTS.map(t => {
    let score = 0;
    t.specialties.forEach(s => { if (pl.includes(s.toLowerCase())) score += 3; });
    if (/anxious|anxiety|panic|worry|stress/.test(pl) && t.specialties.includes('anxiety')) score += 5;
    if (/depress|sad|hopeless|empty|numb/.test(pl) && t.specialties.includes('depression')) score += 5;
    if (/relationship|marriage|couple|partner|husband|wife/.test(pl) && t.specialties.includes('couples counseling')) score += 5;
    if (/grief|loss|death|mourn|bereave/.test(pl) && t.specialties.includes('grief')) score += 5;
    if (/child|kid|adhd|teen|adolescen/.test(pl) && (t.specialties.includes('ADHD') || t.specialties.includes('childhood trauma'))) score += 5;
    if (/trauma|ptsd|abuse|assault/.test(pl) && (t.specialties.includes('trauma') || t.specialties.includes('PTSD'))) score += 5;
    if (/addiction|substance|alcohol|drug/.test(pl) && t.specialties.includes('substance abuse')) score += 5;
    if (/ocd|obsess|compuls/.test(pl) && t.specialties.includes('OCD')) score += 5;
    if (t.accepted_insurance.some(ins => il.includes(ins.toLowerCase()))) score += 2;
    return { therapist: t, score };
  });
  return scored.filter(s => s.score > 0).sort((a, b) => b.score - a.score).slice(0, 3).map(s => s.therapist);
}

export function answerGeneralQuestion(question: string): string {
  const lower = question.toLowerCase();

  if (/what is mindbridge|about mindbridge|what do you do|what is this|what.*platform/.test(lower)) {
    return `**MindBridge** is an AI-powered mental healthcare scheduling platform.\n\nI help you:\n• Find the right licensed therapist based on your specific needs\n• Verify insurance coverage instantly\n• Book appointments directly on your therapist's calendar\n\nThe entire process takes about 5 minutes — no phone calls, no waiting.`;
  }
  if (/how does.*(work|match)|how do you match|how.*find/.test(lower)) {
    return `Here's how matching works:\n\n1️⃣ Tell me what you're going through\n2️⃣ I identify the right specialty (anxiety, grief, trauma, etc.)\n3️⃣ I check which therapists accept your insurance\n4️⃣ I rank by best fit and show you top matches\n5️⃣ You pick one and book — done!\n\nYou can also skip all of this and directly say something like *"I want to book with Dr. Mitchell at 3pm tomorrow"* and I'll handle it right away.`;
  }
  if (/insurance|coverage|in.network|which insurance/.test(lower)) {
    return `We work with most major insurance plans:\n\n• **Aetna** • **BlueCross BlueShield** • **Cigna**\n• **United Healthcare** • **Humana** • **Medicaid**\n• **Medicare** • **Tricare** • **Self-pay / No insurance**\n\nEach therapist accepts different plans — I'll filter matches by your insurance automatically.`;
  }
  if (/how long|session length|duration|how many minutes/.test(lower)) {
    return `Standard therapy sessions are **50 minutes**. Some therapists also offer:\n• 30-minute check-ins (follow-up sessions)\n• 90-minute intensive sessions\n\nYou can discuss preferred session length with your therapist at your first appointment.`;
  }
  if (/cost|price|fee|how much|pay|expensive/.test(lower)) {
    return `Session costs vary:\n\n• **With insurance**: typically a $20–$60 copay\n• **Self-pay**: $120–$200 per session\n• Many therapists offer **sliding scale fees** based on income\n\nI recommend confirming your exact copay with your insurance before your first session.`;
  }
  if (/cancel|reschedule|change appointment/.test(lower)) {
    return `Cancellation policy:\n\n✅ Cancel **24+ hours ahead**: no charge\n⚠️ Cancel **under 24 hours**: possible late-cancel fee\n❌ **No-show**: full session fee may apply\n\nTo cancel or reschedule, use the link in your confirmation email or call the clinic directly.`;
  }
  if (/list.*therapist|who.*therapist|available.*doctor|your therapist|show.*therapist/.test(lower)) {
    const list = MOCK_THERAPISTS.map(t => `• **${t.name}** — ${t.title}\n  Specializes in: ${t.specialties.slice(0,3).join(', ')}`).join('\n');
    return `Here are all our available therapists:\n\n${list}\n\nWant to book with any of them? Just say something like *"Book with Dr. Mitchell at 2pm tomorrow"* and I'll check availability right away!`;
  }
  if (/confidential|private|hipaa|secure|data|safe/.test(lower)) {
    return `Your privacy is our top priority:\n\n🔒 **HIPAA-compliant** — all data is encrypted at rest and in transit\n🔒 **Confidential** — your conversations are never shared or sold\n🔒 **Secure sessions** — therapist notes are completely private\n\nThe only legal exception is if there's an imminent risk of harm to yourself or others.`;
  }
  if (/emergency|crisis|suicid|harm|urgent|help now/.test(lower)) {
    return `If you're in immediate danger, please reach out right away:\n\n🆘 **Emergency**: Call **911**\n📞 **988 Suicide & Crisis Lifeline**: call or text **988**\n💬 **Crisis Text Line**: text HOME to **741741**\n\nMindBridge is for scheduled therapy — not a crisis service. Please use the resources above if you need immediate help. 💙`;
  }
  if (/thank|thanks|appreciate|helpful/.test(lower)) {
    return `You're very welcome! 😊 Happy to help. Is there anything else — booking an appointment, checking a therapist's availability, or any other questions?`;
  }
  if (/^(hi|hello|hey|howdy|good\s*(morning|afternoon|evening)|namaste)\b/.test(lower)) {
    return `Hello! 👋 Great to have you here.\n\nI can help you:\n• **Find & book a therapist** based on your needs\n• **Book directly** — e.g., *"Book Dr. Mitchell at 3pm tomorrow"*\n• **Check availability** — e.g., *"Is Dr. Chen free on Friday?"*\n• **Answer questions** about our services, insurance, pricing, etc.\n\nWhat would you like to do today?`;
  }
  return '';
}

// ─── Mock admin data ───────────────────────────────────────────────────────────
export const MOCK_INQUIRIES: Inquiry[] = [
  {
    id: 'inq-1', patient_identifier: 'patient-hash-001',
    problem_description: 'I have been experiencing severe anxiety and panic attacks for the past 3 months, especially at work.',
    requested_schedule: 'Weekday evenings after 6pm', insurance_info: 'Aetna',
    extracted_specialty: 'anxiety', matched_therapist_id: '1', status: 'scheduled',
    created_at: '2025-04-15T14:22:00Z', therapist: MOCK_THERAPISTS[0],
  },
  {
    id: 'inq-2', patient_identifier: 'patient-hash-002',
    problem_description: 'My husband and I have been having communication issues and we feel disconnected.',
    requested_schedule: 'Saturday mornings', insurance_info: 'BlueCross',
    extracted_specialty: 'couples counseling', matched_therapist_id: '2', status: 'matched',
    created_at: '2025-04-16T09:45:00Z', therapist: MOCK_THERAPISTS[1],
  },
  {
    id: 'inq-3', patient_identifier: 'patient-hash-003',
    problem_description: 'Struggling with grief after losing my mother last year. Finding it hard to function.',
    requested_schedule: 'Flexible', insurance_info: 'Humana',
    extracted_specialty: 'grief', matched_therapist_id: '2', status: 'pending',
    created_at: '2025-04-18T11:30:00Z',
  },
  {
    id: 'inq-4', patient_identifier: 'patient-hash-004',
    problem_description: 'My 10-year-old son has been diagnosed with ADHD and we need help managing his behavior.',
    requested_schedule: 'After school, 3-5pm', insurance_info: 'BlueCross',
    extracted_specialty: 'ADHD', matched_therapist_id: '4', status: 'scheduled',
    created_at: '2025-04-19T16:00:00Z', therapist: MOCK_THERAPISTS[3],
  },
  {
    id: 'inq-5', patient_identifier: 'patient-hash-005',
    problem_description: 'Going through a difficult career transition and feeling lost about my identity and purpose.',
    requested_schedule: 'Any weekday', insurance_info: 'Cigna',
    extracted_specialty: 'life transitions', matched_therapist_id: '5', status: 'matched',
    created_at: '2025-04-20T08:15:00Z', therapist: MOCK_THERAPISTS[4],
  },
];

export const MOCK_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-1', inquiry_id: 'inq-1', therapist_id: '1', patient_identifier: 'patient-hash-001',
    start_time: '2025-04-22T18:00:00Z', end_time: '2025-04-22T19:00:00Z',
    google_calendar_event_id: 'gcal-event-001', status: 'confirmed',
    created_at: '2025-04-15T14:30:00Z', therapist: MOCK_THERAPISTS[0], inquiry: MOCK_INQUIRIES[0],
  },
  {
    id: 'apt-2', inquiry_id: 'inq-4', therapist_id: '4', patient_identifier: 'patient-hash-004',
    start_time: '2025-04-23T15:00:00Z', end_time: '2025-04-23T16:00:00Z',
    status: 'confirmed', created_at: '2025-04-19T16:30:00Z',
    therapist: MOCK_THERAPISTS[3], inquiry: MOCK_INQUIRIES[3],
  },
  {
    id: 'apt-3', inquiry_id: 'inq-2', therapist_id: '2', patient_identifier: 'patient-hash-002',
    start_time: '2025-04-26T10:00:00Z', end_time: '2025-04-26T11:00:00Z',
    status: 'confirmed', created_at: '2025-04-16T10:00:00Z',
    therapist: MOCK_THERAPISTS[1], inquiry: MOCK_INQUIRIES[1],
  },
];
